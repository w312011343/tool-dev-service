//地图绘制类
const Map = {
  //画出地图
  draw(map) {
    let i, j;

    for (i = 0; i < 10; i++) {
      for (j = 0; j < 10; j++) {
        //画背景地图
        let target = MapData[i][j];
        let x = j * 50;
        let y = i * 50;
        if (target == 0) Canvas.drawRect(map, x, y, 50, 50, "red");
        //画可以走的路
        else if (target === 1) {
          Canvas.fillRect(map, x, y, 50, 50, "black");
        } else if (target === 2) {
          // Canvas.fillRect(map, j * 50, i * 50, 50, 50, "yellow");
          const img = document.getElementById("tower_img");
          const towerMap = [
            { x: 0, y: 0 },
            { x: 50, y: 0 },
            { x: 100, y: 0 },
            { x: 150, y: 0 },
            { x: 200, y: 0 },
          ];
          const random = parseInt(Math.random() * 5);
          Canvas.drawImg(
            map,
            img,
            towerMap[random].x,
            towerMap[random].y,
            50,
            50,
            x,
            y,
            50,
            50
          );
        } else if (target === 3) {
          // 充电站
          const img = document.getElementById("gas_img");
          Canvas.drawImg(map, img, 0, 0, 50, 50, x, y, 50, 50);
        }
      }
    }
  },
};
