//游戏数据控制类
var Game = {
  //图片列表信息
  imgList: {},
  //画布列表信息
  canvasList: {},
  //塔的列表
  towerList: [],
  //敌人类表
  enemyList: [],
  //子弹列表
  bulletList: [],
  //关卡数
  mission: 2,
  //每关已出的敌人数
  missionEnemy: 0,
  //每关的休息时间
  missionTime: 2000,
  //每关的延迟时间
  missionLazy: 2000,
  //每个敌人的出场间隔时间
  enemyTime: 1000,
  //每个敌人的出场间隔延迟
  enemyLazy: 0,
  //计时器ID
  timer: 0,
  //当前选中的塔
  nowSelectTower: null,
  //初始化
  init: function () {
    this.initImg();
    this.initCanvas();
    this.initData();
    this.initBind();
  },
  //初始化图片
  initImg: function () {
    this.imgList = {
      // enemy_img: document.getElementById("enemy_img"),
      enemy_img: [
        document.getElementById("car1_img"),
        document.getElementById("car2_img"),
        document.getElementById("car3_img"),
      ],
      tower_img: document.getElementById("tower_img"),
      bullet_img: document.getElementById("bullet_img"),
      btn_img: document.getElementById("btn_img"),
    };
  },
  //初始化画布
  initCanvas: function () {
    this.canvasList = {
      map: document.getElementById("map").getContext("2d"),
      main: document.getElementById("main").getContext("2d"),
      info: document.getElementById("info").getContext("2d"),
      select: document.getElementById("select").getContext("2d"),
      tower: document.getElementById("tower").getContext("2d"),
    };
  },
  //初始化数据
  initData: function () {
    Info.init(this.canvasList.info, this.imgList.tower_img);
  },
  //初始化绑定塔的事件
  initBind: function () {
    var select = document.getElementById("select");

    select.onclick = function (e) {
      var x = e.offsetX || e.layerX,
        y = e.offsetY || e.layerY;
      //遍历塔的列表
      for (var i = 0, l = Game.towerList.length; i < l; i++) {
        //判断是否选择到了塔
        if (T.pointInRect({ x: x, y: y }, Game.towerList[i])) {
          //画出范围
          Info.drawScope(Game.towerList[i]);

          if (Game.nowSelectTower) {
            //升级或卖掉
            Info.upgradeOrSell(x, y);
          }

          Game.nowSelectTower = Game.towerList[i];

          break;
        }
      }
      //没有选中,清除
      if (i == l) {
        Canvas.clear(
          Game.canvasList.select,
          window.games.mapWidth,
          window.games.mapHeight
        );

        Game.nowSelectTower = null;
      }
    };
  },
  //出敌人
  initEnemy(index) {
    if (Game.missionEnemy > 20) {
      // 敌人数量大于20
      Game.missionEnemy = 1;

      Game.mission += 1;
      Info.updateMission();

      Game.missionLazy = Game.missionTime;
      if (Game.mission >= 20) {
        Game.initEnemy = function () {
          if (Game.enemyList.length <= 0) Game.win();
        };
        return false;
      }

      return false;
    }

    Game.missionEnemy += 1;
    //新增一个敌人
    let type = parseInt(Math.random() * 20);
    const algorithm = {
      0: window.games.algorithmList.one,
      1: window.games.algorithmList.two,
      2: window.games.algorithmList.one,
    };
    var enemy = new Enemy(
      Game.canvasList.main,
      Game.imgList.enemy_img[Game.missionEnemy - 1],
      type,
      algorithm[index],
      0,
      0,
      25,
      25
    );
    enemy.num = type * 20 + Game.missionEnemy;

    Game.enemyList.push(enemy);
  },
  //开始
  start: function () {
    Canvas.clear(
      Game.canvasList.main,
      window.games.mapWidth,
      window.games.mapHeight
    );
    const terms = window.games.terms || 2;
    for (let index = 0; index < terms; index++) {
      Game.initEnemy(index);
    }
    // drawEnemy();
    this.timer = setInterval(Game.loop, 20);
  },
  //重新开始
  restart: function () {
    this.start();
  },

  //停止
  stop: function () {
    clearInterval(this.timer);
  },
  //结束
  over: function () {
    this.stop();
    alert("你输了!");
  },
  //赢了
  win: function () {
    this.stop();
    alert("你赢了!");
  },
  //循环体
  loop: function () {
    Canvas.clear(
      Game.canvasList.main,
      window.games.mapWidth,
      window.games.mapHeight
    );

    // Game.initEnemy();

    drawEnemy();
    drawBullet();

    updateEnemy();
    updateTower();
    updateBullet();
  },

  /**
   * 默认绘制地图
   */
  drawMap() {
    this.stop();

    this.towerList = [];
    this.enemyList = [];
    this.bulletList = [];
    this.mission = 0;
    this.missionEnemey = 0;
    this.missionLazy = 2000;
    this.enemyLazy = 0;
    this.nowSelectTower = null;

    Info.score = 100;
    Info.life = 10;
    Info.mission = 1;
    Info.installTower = {};
    const wid = window.games.mapWidth;
    const height = window.games.mapHeight;

    Canvas.clear(this.canvasList.map, wid, height);
    Canvas.clear(this.canvasList.main, wid, height);
    Canvas.clear(this.canvasList.tower, wid, height);
    Canvas.clear(this.canvasList.select, wid, height);
    Info.redraw();
    // switch (document.getElementById("select_map").value) {
    //   case "1":
    //     MapData = MapOne;
    //     break;
    //   case "2":
    //     MapData = MapTwo;
    //     break;
    //   default:
    //     MapData = MapOne;
    //     break;
    // }
    MapData = MapOne;
    Map.draw(this.canvasList.map);
  },
};

Game.init();
