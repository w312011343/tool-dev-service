//地图绘制类
const Map = {
  //画出地图
  draw(map) {
    let i, j;

    for (i = 0; i < 10; i++) {
      for (j = 0; j < 10; j++) {
        //画背景地图
        let target = MapData[i][j];
        let x = j * 50;
        let y = i * 50;
        if (target == 0) Canvas.drawRect(map, x, y, 50, 50, "red");
        else if (target === 1) {
          //画可以走的路
          Canvas.fillRect(map, x, y, 50, 50, "#000");
          this.drawRoadBounday({
            MapData,
            map,
            x,
            y,
            width: 50,
            height: 50,
            i,
            j,
          });
        } else if (target === 2) {
          // Canvas.fillRect(map, j * 50, i * 50, 50, 50, "yellow");
          const img = document.getElementById("tower_img");
          const towerMap = [
            { x: 0, y: 0 },
            { x: 50, y: 0 },
            { x: 100, y: 0 },
            { x: 150, y: 0 },
            { x: 200, y: 0 },
          ];
          const random = parseInt(Math.random() * 5);
          Canvas.drawImg(
            map,
            img,
            towerMap[random].x,
            towerMap[random].y,
            50,
            50,
            x,
            y,
            50,
            50
          );
        } else if (target === 3) {
          // 充电站
          const img = document.getElementById("gas_img");
          Canvas.drawImg(map, img, 0, 0, 50, 50, x, y, 50, 50);
        }
      }
    }
  },
  drawRoadBounday({ MapData, map, x, y, width, height, i, j }) {
    Canvas.clearRect(map, x, y, 51, 51);
    Canvas.drawRect(map, x, y + 1, width, height - 1, "green");
    // let preX = i - 1;
    // let preY = j - 1;
    // let nextX = i + 1;
    // let nextY = j + 1;
    // let left = null;
    // let top = null;
    // let right = null;
    // let bottom = null;
    // if (preX >= 0) {
    //   left = MapData[preX][j];
    // }
    // if (preY >= 0) {
    //   top = MapData[i][preY];
    // }
    // if (nextX < 10) {
    //   right = MapData[nextX][preY];
    // }
    // if (nextY < 10) {
    //   bottom = MapData[i][nextY];
    // }

    // if (left && left === 1) {
    //   console.log("左边 ============", x, y);
    //   // 擦除左边
    //   Canvas.clearRect(map, x, y, 1, height);
    // }
    // if (top && top === 1) {
    //   console.log("上边 ============", x, y);
    //   // 擦除上边
    //   Canvas.clearRect(map, x, y, width, 1);
    // }
    // if (right && right === 1) {
    //   console.log("右边 ============", x, y);
    //   // 擦除右边
    //   Canvas.clearRect(map, x + 50 - 1, y, 1, height);
    // }

    // if (bottom && bottom === 1) {
    //   console.log("下边 ============", x, y);
    //   // 擦除下标
    //   Canvas.clearRect(map, x, y + 50 - 1, width, 1);
    // }

    // Canvas.clearRect(map, x, y, 51, 51);
    Canvas.fillRect(map, x, y, 50, 50, "#000");
    // Canvas.clearRect(map, x, y, 1, height);
    // Canvas.clearRect(map, x + 50 - 1, y, 1, height);
    // Canvas.clearRect(map, x, y + 50 - 1, width, 1);
  },
};
