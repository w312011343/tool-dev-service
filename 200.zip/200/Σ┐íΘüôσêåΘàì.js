/**
 * 
 

https://www.online1987.com/%e4%bf%a1%e9%81%93%e5%88%86%e9%85%8d/

■ 题目描述

【信道分配】

算法工程师小明面对着这样一个问题 ，需要将通信用的信道分配给尽量多的用户:

信道的条件及分配规则如下:

1)所有信道都有属性:”阶”。阶为 r的信道的容量为 2^r比特;

2)所有用户需要传输的数据量都一样:D比特;

3)一个用户可以分配多个信道，但每个信道只能分配给一个用户;

4)只有当分配给一个用户的所有信道的容量和>=D，用户才能传输数据;

给出一组信道资源，最多可以为多少用户传输数据?

输入描述

第一行，一个数字 R。R为最大阶数。0<=R<20

第二行，R+1个数字，用空格隔开。

代表每种信道的数量 Ni。按照阶的值从小到大排列。

0<=i<=R,0<=Ni<1000.

第三行，一个数字 D。

D为单个用户需要传输的数据量。0<D<1000000

输出描述

一个数字,代表最多可以供多少用户传输数据。

示例 1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5
10 5 0 1 3 2
30
输出

4

 */

let R = Number(readLine());
let nInput = readLine()
  .split(" ")
  .map((i) => parseInt(i));

// let R = Number("5");
// let nInput = "10 5 0 1 3 2".split(" ").map(i=>parseInt(i));

let N = [];
for (let i = 0; i <= R; i++) {
  N[i] = nInput[i];
}

let D = Number(readLine());
//let D = Number("30");
let list = [];

let res = 0; //支持用户数量
for (let i = 0; i <= R; i++) {
  for (let j = 0; j < N[i]; j++) {
    let num = Math.pow(2, i); //信道容量
    if (num >= D) {
      //信道容量大于用户需求时直接满足
      res++;
      continue;
    }
    list.push(num);
  }
}

let isEnough = true; //是否够一个用户使用
while (isEnough) {
  let count = list[list.length - 1]; //取最大的信道
  list.splice(list.length - 1, 1); //取完需要剔除
  while (count < D && isEnough) {
    let min = Number.MAX_VALUE;
    let minindex = 0;
    let temp = 0;
    for (let i = 0; i < list.length; i++) {
      temp += list[i];
      let chazhi = Math.abs(D - count - list[i]); //求出与所需信道最接近的信道
      min = Math.min(min, chazhi);
      if (min == chazhi) {
        minindex = i;
      }
    }
    count += list[minindex];
    list.splice(minindex, 1);
    if (count >= D) {
      res++;
      break;
    }
    if (count + temp < D) {
      //总共的信道不够一个用户使用
      isEnough = false;
    }
  }
}
console.log(res);




import collections

if __name__ == "__main__":
    while True:
        try:
            N = int(input())
            l = list(map(int, input().split()))
            d = collections.defaultdict(int)
            for i in range(len(l)):
                d[2 ** i] = l[i]
            tar = int(input())
        except EOFError:
            break

    res = 0
    for k, v in d.items():
        if k >= tar:
            res += v
            d[k] = 0
    t = tar
    for k, v in sorted(d.items(), key=lambda x: x[0]):
        while v > 0:
            t -= k
            v -= 1
            if t <= 0:
                res += 1
                t = tar
    print(res)