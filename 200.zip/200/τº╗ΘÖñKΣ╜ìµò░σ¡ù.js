/**
 * 
 https://www.online1987.com/%e7%a7%bb%e9%99%a4k%e4%bd%8d%e6%95%b0%e5%ad%97/
【移除K位数字】

给一个正整数NUM1，计算出新正整数NUM2，NUM2为NUM1中移除N位数字后的结果，需要使得NUM2的值最小。

输入描述：

1.输入的第一行为一个字符串，字符串由0-9字符组成，记录正整数NUM1，NUM1长度小于32。
2.输入的第二行为需要移除的数字的个数，小于NUM1长度。

如：
2615371
4

输出描述：

输出一个数字字符串，记录最小值NUM2。
如：131

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

2615371
4

说明

移除2、6、5、7这四个数字，剩下1、3、1按原有顺序排列组成131，为最小值。
 */

let s = readLine();
let m = Number(readLine());
// let  s = "2615371";
// let m = Number("4");

let l = m + 1; //截取字符的右边界
let index = 0;
let res = "";

while (res.length < s.length - m) {
  let str = s.substring(index, l); //求出第一个数字的最小值
  let min = Number.MAX_VALUE;
  let len = str.length;
  let ints = [];
  for (let i = 0; i < len; i++) {
    let temp = str.charAt(i); //char转换成int
    ints[i] = temp; //放入数组求出下标
    if (res == "" && temp == 0) {
      //第一位不能为0（如没有要求可以删掉）
      continue;
    }
    min = Math.min(min, temp);
  }
  res += String(min);

  for (let i = 0; i < len; i++) {
    if (ints[i] == min) {
      index += i; //求出第一个最小值的下标然后去截取循环获取最小值
      break;
    }
  }
  index++;
  l++; //数字要往后移一位
}

console.log(res);
