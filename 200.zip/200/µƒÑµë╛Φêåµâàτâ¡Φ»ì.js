/**
 
【编程题目 | 100分】查找舆情热词 

编程题 第1/3题

1、查找舆情热词

网上新闻越来越多，希望对新闻进行热词处理并归类，方便获取信息、现在已经将每篇新闻处理为2个字符串，即一个标题串和一个正文串，字符串中使用” “（空格）作为分隔词语的分隔符进行分词。

M篇新闻按照新闻发布的先后顺序处理完并输入，现在希望对所有新闻中出现的词语进行处理，输出出现频率最高的topN个词语作为热词。

排序规则

标题中出现的词语频率系数为3，正文中出现的词语频率系数为1；
返回的答案应该按照词语出现频率由高到低排序，当词语出现的频率相同时，在标题中出现的频率次数高的排在前面；
如果仍然相同，则按照词语在标题中出现的先后顺序进行排序，先出现的排在前面；
如果仍然相同，则按照词语在正文中出现的先后顺序进行排序，先出现的排在前面。


输入

第一行输入为正整数topN和文章数M，即要输出的出现频率最高的词语的个数和处理的文章的数量，
由于每篇文章被处理为标题和正文2行，因此后面有2*M行数据。
从第二行起，是按顺序处理后每篇文章的标题串和正文串，
即第二行是第一篇文章的标题串，第三行是第一篇文章的正文串，
第四行是第二篇文章的标题串，第五行是第二篇文章的正文串，以此类推。
参数限制如下：

0 < topN < 1000
0 < M < 100000
0 < 每篇文章的词语数 < 5000
输出

使用一行输出出现频率最高的topN个词语，每个词语以” “隔开。
样例 1

输入：

3 2
xinguan feiyan xinzeng bendi quezhen anli
ju baodao chengdu xinzeng xinguan feiyan bendi quezhen anli yili shenzhen xinzeng bendi quezhen anli liangli yiqing zhengti kongzhi lianghao
xinguan yimiao linchuang shiyan
wuzhong xinguan yimiao tongguo sanqi linchaung shiyan xiaoguo lianghao
新冠肺炎本地确诊案例

据报道成都新增新冠肺炎本地确诊案例一例，深圳新增案例两例，疫情整体控制良好，本地确诊案例两例，疫情整体控制良好。

新冠疫苗临床试验

五种新冠疫苗通过三期临床试验，效果良好。

输出：

xinguan xinzeng bendi
 

各词语出现频率：

xinguan=2*3+2=8

feiyan=1*3+1=4

xinzeng=1*3+2=5

bendi=1*3+2=5

quezhen=1*3+2=5

anli=1*3+2=5

yimiao=1*3+1=4

linchuang=1*3+1=4

shiyan=1*3+1=4，返回最高频率的3个词语，有4个词语出现频率都为5，标题出现频率都为3，所以选择先出现的两个词语”xinzeng”和”bendi”。

样例 2

输入：

1 2

xinguan feiyan xinzeng bendi quezhen anli

jubaodao chengdu xinzeng xinguan feiyan bendi quezhen anli yili shenzhen xinzeng bendi quezhen anli liangli yiqing zhengti kongzhi lianghao

xinguan yimiao linchuang shiyan

wuzhong xinguan yimiao tongguo sanqi linchaung shiyan xiaoguo lianghao

新冠肺炎本地确诊案例

据报道成都新增新冠肺炎本地确诊案例一例，深圳新增新冠肺炎本地确诊案例两例，疫情整体控制良好。

新冠疫苗临床试验

五种新冠疫苗通过三期临床试验，效果良好。

 

输出：

 

xinguan

 

解释：

各词语出现频率：

xinguan=2*3+2=8

feiyan=1*3+1=4

xinzeng=1*3+2=5

bendi=1*3+2=5

quezhen=1*3+2=5

anli=1*3+2=5

yimiao=1*3+1=4

linchuang=1*3+1=4

shiyan=1*3+1=4，返回最高频率的1个词语，所以是频率为8的”xinguan”。
 */

function* readline() {
  // yield "1 2";
  // yield "xinguan feiyan xinzeng bendi quezhen anli";
  // yield "jubaodao chengdu xinzeng xinguan feiyan bendi quezhen anli yili shenzhen xinzeng bendi quezhen anli liangli yiqing zhengti kongzhi lianghao";
  // yield "xinguan yimiao linchuang shiyan";
  // yield "wuzhong xinguan yimiao tongguo sanqi linchaung shiyan xiaoguo lianghao";

  yield "3 2";
  yield "xinguan feiyan xinzeng bendi quezhen anli";
  yield "jubaodao chengdu xinzeng xinguan feiyan bendi quezhen anli yili shenzhen xinzeng bendi quezhen anli liangli yiqing zhengti kongzhi lianghao";
  yield "xinguan yimiao linchuang shiyan";
  yield "wuzhong xinguan yimiao tongguo sanqi linchaung shiyan xiaoguo lianghao";
}

getResult();
function getResult() {
  const fn = readline();
  const [n, num] = fn.next().value.split(" ").map(Number);
  let match = {};
  for (let i = 0; i < num; i++) {
    const titles = fn.next().value.split(" ");
    const pages = fn.next().value.split(" ");

    titles.forEach((title, index) => {
      match[title] = match[title] || {
        word: title,
        num: 0,
        titleNum: 0,
        titileFisrt: index,
      };
      match[title].num += 3;
      match[title].titleNum += 3;
      // 替换单词第一次出现的位置
      if (match[title].titileFisrt > index) {
        match[title].titileFisrt = index;
      }
    });

    pages.forEach((page, index) => {
      match[page] = match[page] || {
        word: page,
        num: 0,
        pageFirst: index,
      };
      match[page].num += 1;
      // 替换单词第一次出现的位置
      if (match[page].pageFirst > index) {
        match[page].pageFirst = index;
      }
    });
  }

  const values = Object.values(match);

  values.sort((a, b) => {
    if (a.num != b.num) {
      // 按照比重从大到小排
      return b.num - a.num;
    } else {
      if (a.titleNum != b.titleNum) {
        // 按照标题出现次数从大到小排
        return b.titleNum - a.titleNum;
      } else {
        if (a.titileFisrt != b.titileFisrt)
          // 按照标题出现位置排，先出现先排
          return a.titileFisrt - b.titileFisrt;
        // 按照文章出现位置排，先出现先排
        else return a.pageFirst - b.pageFirst;
      }
    }
  });

  let temp = [];
  for (let i = 0; i < n; i++) {
    temp.push(values[i].word);
  }
  console.log(temp.join(" "));
}

function getSort(a, b, key, flag) {
  if (a[key] && !b[key]) {
    return 1;
  }
  if (!a[key] && b[key]) {
    return -1;
  }
  if (flag) {
    if (a[key] > b[key]) {
      return 1;
    }
  } else {
  }

  return -1;
}
