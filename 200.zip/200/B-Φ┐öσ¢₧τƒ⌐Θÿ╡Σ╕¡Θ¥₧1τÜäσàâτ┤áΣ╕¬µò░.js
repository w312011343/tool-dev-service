/**
 * 
 https://www.online1987.com/%e8%bf%94%e5%9b%9e%e7%9f%a9%e9%98%b5%e4%b8%ad%e9%9d%9e1%e7%9a%84%e5%85%83%e7%b4%a0%e4%b8%aa%e6%95%b0/
【返回矩阵中非1的元素个数】

存在一个m*n的二维数组，其成员取值范围为0，1，2。
其中值为1的元素具备同化特性，每经过1S，将上下左右值为0的元素同化为1。
而值为2的元素，免疫同化。
将数组所有成员随机初始化为0或2，再将矩阵的[0, 0]元素修改成1，
在经过足够长的时间后求矩阵中有多少个元素是0或2（即0和2数量之和）。

输入描述

输入的前两个数字是矩阵大小。后面是数字矩阵内容。

输出描述

返回矩阵中非1的元素个数。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

4 4
0 0 0 0
0 2 2 2
0 2 0 0
0 2 0 0
输出

9
说明

输入数字前两个数字是矩阵大小。后面的数字是矩阵内容。
起始位置(0,0)被修改为1后，最终只能同化矩阵为：

4 4
0 0 0 0
0 2 2 2
0 2 0 0
0 2 0 0
所以矩阵中非1的元素个数为9。

 */
// const readline = require("readline");

// const rl = readline.createInterface({
//   input: process.stdin,
//   output: process.stdout,
// });

// const lines = [];
// let m, n;
// rl.on("line", (line) => {
//   lines.push(line);

//   if (lines.length == 1) {
//     [m, n] = lines[0].split(" ").map(Number);
//   }

//   if (m && lines.length == m + 1) {
//     lines.shift();

//     const matrix = lines.map((s) => s.split(" ").map(Number));
//     matrix[0][0] = 1;

//     console.log(getResult(m, n, matrix));
//   }
// });

// function getResult(m, n, matrix) {
//   // 上、下、左、右偏移量
//   const offsets = [
//     [-1, 0],
//     [1, 0],
//     [0, -1],
//     [0, 1],
//   ];

//   // 广搜队列, 初始时只有矩阵[0,0]位置元素为1
//   const queue = [[0, 0]];

//   // count记录矩阵中值为1的元素的个数
//   let count = 1;

//   // 广搜
//   while (queue.length > 0) {
//     const [x, y] = queue.shift();

//     for (let offset of offsets) {
//       const newX = x + offset[0];
//       const newY = y + offset[1];

//       if (
//         newX >= 0 &&
//         newX < m &&
//         newY >= 0 &&
//         newY < n &&
//         matrix[newX][newY] == 0
//       ) {
//         matrix[newX][newY] = 1;
//         count++;
//         queue.push([newX, newY]);
//       }
//     }
//   }

//   return m * n - count;
// }
function* readline() {
  yield "4 4";
  yield "0 0 0 0";
  yield "0 2 2 2";
  yield "0 2 0 0";
  yield "0 2 0 0"; //  9
}
getResult();
function getResult() {
  const fn = readline();
  const [m, n] = fn.next().value.split(" ").map(Number);
  const list = [];
  for (let i = 0; i < m; i++) {
    list.push(fn.next().value.split(" ").map(Number));
  }
  list[0][0] = 1;

  const queen = [[0, 0]];
  let count = 1;

  const offsets = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ];
  while (queen.length) {
    const [x, y] = queen.shift();
    for (const offset of offsets) {
      const [offsetX, offsetY] = offset;
      const newX = offsetX + x;
      const newY = offsetY + y;
      if (newX < 0 || newX >= m || newY < 0 || newY >= n) {
        continue;
      }
      if (list[newX][newY] !== 0) {
        continue;
      }
      list[newX][newY] = 1;
      count++;
      queen.push([newX, newY]);
    }
  }
  console.log(m * n - count);
}
