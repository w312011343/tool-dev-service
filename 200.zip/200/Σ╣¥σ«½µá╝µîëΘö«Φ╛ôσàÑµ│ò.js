/**
 
https://www.online1987.com/%e4%b9%9d%e5%ae%ab%e6%a0%bc%e6%8c%89%e9%94%ae%e8%be%93%e5%85%a5%e6%b3%95/


九宫格按键输入，判断输出，有英文和数字两个模式，默认是数字模式，数字模式直接输出数字，英文模式连续按同一个按键会依次出现这个按键上的字母，如果输入”/”或者其他字符，则循环中断。

要求输入一串按键，输出屏幕显示。

输入描述：

输入范围为数字 0~9 和字符’#’、’/’，输出屏幕显示，例如，

在数字模式下，输入 1234，显示 1234

在英文模式下，输入 1234，显示,adg

输出描述：

#用于切换模式，默认是数字模式，执行#后切换为英文模式；
/表示延迟，例如在英文模式下，输入 22/222，显示为 bc；
英文模式下，多次按同一键，例如输入 22222，显示为 b；
示例 1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

123#222235/56

输出

123adjjm




 */

let s = readLine();
//let s = "#222233";

var temp = ""; //上一次的数字按键
var sb = ""; //输出字符串
var count = 0; //按键次数
var strings = [
  " ",
  ",.",
  "abc",
  "def",
  "ghi",
  "jkl",
  "mno",
  "pqrs",
  "tuv",
  "wxyz",
];
let isEn = false; //英文输入
let len = s.length;

for (let i = 0; i < len; i++) {
  let c = s.charAt(i); //本次的按键
  if (c == "#") {
    //中英文切换
    isEn = !isEn;
    if (temp != "") {
      //temp有值，说明有字符需要输出
      uotput(temp);
      count = 0; //输出完，count和temp初始化
      temp = "";
    }
    continue;
  }
  if (isEn) {
    /**
     * 英文输入
     */
    if (temp == "") {
      if (c == "/") {
        continue;
      }
      temp = c;
      count = 1;
    } else if (temp != c) {
      //按键数字发生变化，需要输出字符
      uotput(temp);
      if (i == len - 1) {
        //最后一个
        uotput(c);
        break;
      }
      if (c == "/") {
        count = 0;
        temp = "";
      } else {
        count = 1;
        temp = c;
      }
    } else {
      count++;
      if (i == len - 1) {
        //最后一个
        uotput(c);
      }
    }
  } else {
    /**
     * 数字输入
     */
    if (c == "/") {
      //数字中的/没有意义
      continue;
    }
    sb += c; //数字直接输出
  }
}

console.log(sb);

function uotput(str) {
  //输出文字

  let strIndex = Number(str); //上一次的按键（数字）
  if (strIndex == 0) {
    sb += " "; //0只有空格
  } else {
    let strLen = strings[strIndex].length; //数字上的字符长度
    let index = count % strLen == 0 ? strLen - 1 : (count % strLen) - 1; //找到数字按钮上的对应字母位置
    sb += strings[strIndex].charAt(index);
  }
}


class Solution:
    def NineGridInputMethod(self, input_str):
        dic = {'1': ',.', '2': 'abc', '3': 'def', '4': 'ghi', '5': 'jkl',
               '6': 'mno', '7': 'pqrs', '8': 'tuv', '9': 'wxyz'}
        num_mode = True  
        length = len(input_str)
        i = 0
        result = ""
        while i < length:
            s: str = input_str[i]
            if s == '#':
                num_mode = not num_mode
                i += 1
                continue
            if s == '/':
                i += 1
                continue
            if num_mode:
                result += s
                i += 1
                continue
            if s == '0':
                result += " "
                i += 1
                continue
            cnt = 0
            while i < length and input_str[i] == s:
                cnt += 1
                i += 1
            string = dic[s]
            result += string[cnt % len(string) - 1]
        return result

if __name__ == "__main__":
    line = str(input().strip())
    function = Solution()
    results = function.NineGridInputMethod(line)
    print(results)
