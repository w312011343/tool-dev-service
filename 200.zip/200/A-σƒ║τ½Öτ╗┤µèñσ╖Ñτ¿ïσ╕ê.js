/**
 
https://www.online1987.com/%e5%9f%ba%e7%ab%99%e7%bb%b4%e6%8a%a4%e5%b7%a5%e7%a8%8b%e5%b8%88/

【基站维护工程师】

小王是一名基站维护工程师，负责某区域的基站维护。
某地方有  n  个基站(1 < n < 10)，已知各基站之间的距离 s(0 < s < 500)，
并且基站 x 到基站 y 的距离，与基站 y 到基站 x 的距离并不一定会相同。
小王从基站 1 出发，途经每个基站 1 次，然后返回基站 1 ，需要请你为他选择一条距离最短的路。

输入描述

站点数n和各站点之间的距离(均为整数)。

输出描述

最短路程的数值

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3
0 2 1
1 0 2
2 1 0
输出

3
 */

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);

  if (lines.length === 1) {
    n = lines[0] - 0;
  }

  if (n && lines.length === n + 1) {
    lines.shift();
    const matrix = lines.map((line) => line.split(" ").map(Number));
    console.log(getResult(matrix, n));
    lines.length = 0;
  }
});

function getResult(matrix, n) {
  const res = [];
  dfs(n, [], [], res);

  let ans = Infinity;

  for (let path of res) {
    let dis = matrix[0][path[0]];
    path.reduce((p, c) => {
      dis += matrix[p][c];
      return c;
    });
    dis += matrix[path.at(-1)][0];
    ans = Math.min(ans, dis);
  }

  return ans;
}

function dfs(n, used, path, res) {
  if (path.length === n - 1) return res.push([...path]);

  for (let i = 1; i < n; i++) {
    if (!used[i]) {
      path.push(i);
      used[i] = true;
      dfs(n, used, path, res);
      used[i] = false;
      path.pop();
    }
  }
}


def solve(n, matrix):
    dp = [[float('inf') for _ in range(1 << n)] for _ in range(n)]
    for i in range(n):
        dp[i][1 << i] = matrix[0][i]

    # j为当前状态
    for j in range(1 << n):
        # i为当前基站
        for i in range(n):
            if ((j & (1 << i)) == 0):
                continue  # 注意运算符优先级
            # k为下一个基站
            for k in range(n):
                dp[i][j] = min(dp[i][j], dp[k][j & (~(1 << i))] + matrix[k][i])

    return dp[0][(1 << n) - 1]


if __name__ == "__main__":
    n = int(input())
    matrix = []
    for i in range(n):
        matrix.append([int(x) for x in input().split(" ")])
    # print(matrix)
    print(solve(n, matrix))