/**
 * 
 https://www.online1987.com/%e8%a7%a3%e5%af%86%e7%8a%af%e7%bd%aa%e6%97%b6%e9%97%b4/

 
 【解密犯罪时间】

警察在侦破一个案件时，得到了线人给出的可能犯罪时间，形如 “HH:MM” 表示的时刻。

根据警察和线人的约定，为了隐蔽，该时间是修改过的，

解密规则为：利用当前出现过的数字，构造下一个距离当前时间最近的时刻，则该时间为可能的犯罪时间。

每个出现数字都可以被无限次使用。

输入描述

形如HH:SS字符串，表示原始输入。

输出描述

形如HH:SS的字符串，表示推理处理的犯罪时间。

备注

1.可以保证现任给定的字符串一定是合法的。

例如，“01:35”和“11:08”是合法的，“1:35”和“11:8”是不合法的。

2.最近的时刻可能在第二天。

示例

20:12得到20:20

23:59得到22:22

12:58得到15:11

18:52得到18:55

23:52得到23:53

09:17得到09:19

07:08得到08:00
 */

let s = readLine();
//let s = "18:52";
let errorTime = Number(s.substring(0, 2) + s.substring(3));
let num = [];
num[0] = s.charAt(0);
num[1] = s.charAt(1);
num[2] = s.charAt(3);
num[3] = s.charAt(4);
let time;
let min = Number.MAX_VALUE; //小于错误时间的最小时间（第二天）
let minThan = Number.MAX_VALUE; //大于错误时间的最小时间
for (let i = 0; i < 4; i++) {
  if (Number(num[i]) > 2) {
    //首位不能大于2
    continue;
  }
  for (let j = 0; j < 4; j++) {
    if (Number(num[i]) == 2 && Number(num[j]) > 3) {
      //第一位为2时第二位则不能大于3
      continue;
    }
    for (let k = 0; k < 4; k++) {
      if (Number(num[k]) > 6) {
        //第三位不能大于6
        continue;
      }
      for (let l = 0; l < 4; l++) {
        time = Number(num[i] + num[j] + num[k] + num[l]); //重构的时间
        if (time < errorTime) {
          min = Math.min(min, time);
        } else if (time > errorTime) {
          minThan = Math.min(minThan, time);
        }
      }
    }
  }
}
let res = "";
if (minThan == Number.MAX_VALUE) {
  //若重构的时间都小于错误时间，则时间为第二天时间
  res = String(min);
} else {
  res = String(minThan);
}
console.log(res.substring(0, 2) + ":" + res.substring(2));
