/**
 * 
 https://www.online1987.com/%e5%af%bc%e5%b8%88%e8%af%b7%e5%90%83%e7%81%ab%e9%94%85/

 【导师请吃火锅】

入职后，导师会请你吃饭，你选择了火锅。

火锅里会在不同时间下很多菜。

不同食材要煮不同的时间，才能变得刚好合适。

你希望吃到最多的刚好合适的菜，但你的手速不够快，用m代表手速，每次下手捞菜后至少要过m秒才能再捞（每次只能捞一个）。

那么用最合理的策略，最多能吃到多少刚好合适的菜？

输入描述

第一行两个整数n，m，其中n代表往锅里下的菜的个数，m代表手速。

接下来有n行，每行有两个数x，y代表第x秒下的菜过y秒才能变得刚好合适。

（1 < n, m < 1000）（1 < x, y < 1000）

输出描述

输出一个整数代表用最合理的策略，最多能吃到刚好合适的菜的数量。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

2 1
1 2
2 1
输出

1

 */
let n = Number(readLine());
let m = Number(readLine());
// let n = Number("4");
// let m = Number("1");

let footList = [];
//let test = ["1 2","1 3","2 3","2 2"];

for (let i = 0; i < n; i++) {
  let nums = readLine()
    .split(" ")
    .map((i) => parseInt(i));
  //let nums = test[i].split(" ").map(i=>parseInt(i));
  footList.push(nums[0] + nums[1]); //所有菜的最佳时机
}

let list = []; //对食物数组进行去重和排序
footList.forEach((v) => {
  if (!list.includes(v)) {
    list.push(v);
  }
});

list.sort();

let count = 0; //吃菜的次数
let len = list.length;
let time = 0; //吃菜的时间
for (let i = 0; i < len; i++) {
  if (time <= list[i]) {
    //吃菜的时间小于菜的最佳时机，表示可以吃上
    count++;
    time = list[i] + m; //这个菜吃完需要过m秒才能再次吃菜
  }
}

console.log(count);
