/**
 https://www.online1987.com/%e6%81%a2%e5%a4%8d%e6%95%b0%e5%ad%97%e5%ba%8f%e5%88%97/
 恢复数字序列】

对于一个连续正整数组成的序列，可以将其拼接成一个字符串，
再将字符串里的部分字符打乱顺序。如序列8 9 10 11 12，拼接成的字符串为89101112，
打乱一部分字符后得到90811211，原来的正整数10就被拆成了0和1。

现给定一个按如上规则得到的打乱字符的字符串，请将其还原成连续正整数序列，并输出序列中最小的数字。

输入描述

输入一行，为打乱字符的字符串和正整数序列的长度，两者间用空格分隔，字符串长度不超过200，
正整数不超过1000，保证输入可以还原成唯一序列。

输出描述

输出一个数字，为序列中最小的数字。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

19801211 5
输出

8

 */
// 方法一
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.on("line", (line) => {
  const [s, k] = line.split(" ");
  console.log(getResult(s, Number(k)));
});

/**
 *
 * @param {*} s 打乱字符的字符串
 * @param {*} k 连续正整数序列的长度
 */
function getResult(s, k) {
  // base：统计打乱字符的字符串中 各字符的数量
  const base = {};
  for (let c of s) {
    base[c] = (base[c] ?? 0) + 1;
  }

  // 初始滑窗（长度k）中各字符的数量
  const count = {};
  for (let i = 1; i <= k; i++) {
    countNumChar(i + "", count, true);
  }

  // 比较滑窗各字符数量，和base统计的各字符数量是否一致，若一致，则说明初始滑窗就是一个符合要求的连续整数数列，该数列的最小值为0
  if (cmp(base, count)) return 0;

  // 否则继续尝试后续滑窗，注意题目说正整数不超过1000，因此我们可以尝试连续正整数序列取值范围就是1~1000
  for (let i = 2; i <= 1000 - k + 1; i++) {
    // 相较于上一个滑窗失去的数字
    const remove = i - 1 + "";
    countNumChar(remove, count, false);

    // 相较于上一个滑窗新增的数字
    const add = i + k - 1 + "";
    countNumChar(add, count, true);

    // 比较
    if (cmp(base, count)) return i;
  }

  return -1; // 题目说存在唯一的序列满足条件，因此这里返回语句是走不到的
}

function countNumChar(num, count, isAdd) {
  for (let c of num) {
    count[c] = (count[c] ?? 0) + (isAdd ? 1 : -1);
  }
}

function cmp(base, count) {
  for (let c in base) {
    if (count[c] === undefined || count[c] != base[c]) {
      return false;
    }
  }
  return true;
}

// 方法二
const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout,
});

readline.question("", (input) => {
  const [s, len] = input.split(" ");
  const minStartNum = findMinStartNum(s, parseInt(len));
  console.log(minStartNum);
  readline.close();
});

function findMinStartNum(s, len) {
  const arr = Array.from(s);
  arr.sort();
  const totalSum = arr.reduce(
    (sum, c) => sum + c.charCodeAt(0) - "0".charCodeAt(0),
    0
  );

  const minNumLen = Math.floor(s.length / len);
  let minNum = Infinity;

  for (let i = 0; i <= 9; i++) {
    const candidate = i.toString() + arr.join("").substring(0, minNumLen - 1);
    const num = parseInt(candidate);
    if (asciiSum(generateSequence(num, len)) === totalSum) {
      minNum = num;
      break;
    }
  }

  return minNum;
}

function generateSequence(startNum, len) {
  let sequence = "";
  for (let i = 0; i < len; i++) {
    sequence += (startNum + i).toString();
  }
  return sequence;
}

function asciiSum(s) {
  return Array.from(s).reduce(
    (sum, c) => sum + c.charCodeAt(0) - "0".charCodeAt(0),
    0
  );
}
