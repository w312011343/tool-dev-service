/**
 * 
 
https://www.online1987.com/%e5%8c%ba%e9%97%b4%e4%ba%a4%e9%9b%86/


题目描述

【区间交集】

给定一组闭区间，其中部分区间存在交集。

任意两个给定区间的交集，称为公共区间(如:[1,2],[2,3]的公共区间为[2,2]，[3,5],[3,6]的公共区间为[3,5])。

公共区间之间若存在交集，则需要合并(如:[1,3],[3,5]区间存在交集[3,3]，需合并为[1,5])。

按升序排列输出合并后的区间列表。

输入描述

一组区间列表，区间数为 N: 0<=N<=1000;区间元素为 X: -10000<=X<=10000。

输出描述

升序排列的合并区间列表

备注:

1、区间元素均为数字，不考虑字母、符号等异常输入。

2、单个区间认定为无公共区间。

示例1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

[[0, 3], [1, 3], [3, 5], [3, 6]]

输出

[[1, 5]]
 */

let list = [];
//let test = ["0 3","1 4","4 7","5 8"];
//let test = ["1 2","3 4"];
let test = ["0 3", "1 3", "3 5", "3 6"];

for (let i = 0; i < test.length; i++) {
  let x = test[i].split(" ");
  let node = new qujian(x[0], x[1]);
  list.push(node);
}

// while (readline()) {
//     let input = readline().split(" ").map(Number);
//     let node = new qujian(input[0], input[1]);
//     list.push(node);
// }

let list1 = [];
collection(list);

for (let i = 0; i < list.length - 1; i++) {
  for (let j = i + 1; j < list.length; j++) {
    let a = list[i];
    let b = list[j];
    if (b.left <= a.right) {
      let l = Math.max(a.left, b.left);
      let r = Math.min(a.right, b.right);
      let node = new qujian(l, r);
      list1.push(node);
    }
  }
}

if (list1.length == 0) {
  console.log("None");
  return;
}
collection(list1);
let l = list1[0].left;
let r = list1[0].right;

for (let i = 1; i < list1.length; i++) {
  let node = list1[i];
  if (node.left > r) {
    console.log(l + " " + r);
    l = node.left;
    r = node.right;
  } else {
    l = Math.min(node.left, l);
    r = Math.max(node.right, r);
  }
}
console.log(l + " " + r);

function qujian(l, r) {
  this.left = l;
  this.right = r;
}

function collection(list) {
  list.sort((a, b) => {
    if (a.left == b.left) {
      return a.right - b.right;
    }
    return a.left - b.left;
  });
}


import sys

arr = []
for line in sys.stdin.readlines():
    if line == '\n':
        break
    arr.append(list(map(int, line.split(' '))))
if len(arr) == 1:
    print(arr[0])
arr.sort(key=lambda x: x[0])
comm_section = []
for i in range(len(arr) - 1):
    for j in range(i + 1, len(arr)):
        if arr[i][-1] >= arr[j][0]:
            comm_section.append([arr[j][0], min(arr[i][-1], arr[j][-1])])
            if len(comm_section) == 1:
                print(comm_section)
comm_section.sort(key=lambda x: x[0])
l = len(comm_section)
i = 0
while i <= l - 2:
    if comm_section[i][-1] > comm_section[i + 1][0]:
        comm_section[i][-1] = max(comm_section[i][-1], comm_section[i + 1][-1])
        comm_section.pop(i + 1)
        l -= 1
    else:
        i += 1
    print(comm_section)