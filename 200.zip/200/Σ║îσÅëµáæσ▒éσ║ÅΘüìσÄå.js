/**
 * 
 https://www.online1987.com/%e4%ba%8c%e5%8f%89%e6%a0%91%e5%b1%82%e5%ba%8f%e9%81%8d%e5%8e%86/
有一棵二叉树，每个节点由一个大写字母标识(最多26个节点）。

现有两组字母，分别表示后序遍历（左孩子->右孩子->父节点）和中序遍历（左孩子->父节点->右孩子）的结果，请你输出层序遍历的结果。

输入

每个输入文件一行，第一个字符串表示后序遍历结果，第二个字符串表示中序遍历结果。（每串只包含大写字母）

中间用单空格分隔。

输出

输出仅一行，表示层序遍历的结果，结尾换行。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

CBEFDA CBAEDF

输出

ABDCEF
 */



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class LevelTraversal {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String s;
        while ((s = br.readLine()) != null) {
            String[] str = s.split(" ");
            Node node = createTree(str[0], str[1]);
            Queue<Node> queue = new LinkedList<>();
            queue.offer(node);
            StringBuilder sb = new StringBuilder();
            while (!queue.isEmpty()) {
                Node head = queue.poll();
                sb.append(head.ch);
                if (head.left != null) {
                    queue.offer(head.left);
                }
                if (head.right != null) {
                    queue.offer(head.right);
                }
            }
            System.out.println(sb);
        }
    }

    public static Node createTree(String a, String b) {
        if (a == null) {
            return null;
        }
        char ch = a.charAt(a.length() - 1);
        Node root = new Node(ch);
        int i = 0;
        while (b.charAt(i) != ch) {
            i++;
        }
        if (i > 0) {
            root.left = createTree(a.substring(0, i), b.substring(0, i));
        } else {
            root.left = null;
        }
        if (b.length() - 1 - i > 0) {
            root.right = createTree(a.substring(i, a.length() - 1), b.substring(i + 1));
        } else {
            root.right = null;
        }
        return root;
    }

    static class Node {
        char ch;
        Node left;
        Node right;

        Node(char ch) {
            this.ch = ch;
        }
    }
}


class Node:
    def __init__(self, val):
        self.data = val
        self.left = None
        self.right = None

hx, zx = input().split()
hx = list(hx)
zx = list(zx)

def create_tree(hx_sub, zx_sub):
    # 子树长度为0或者1时就是叶子节点
    if len(zx_sub) == 1:
        return Node(zx_sub[0])
    elif not zx_sub:
        return None

    # 从后序子树的最后一个元素确定 子树的根节点
    root = hx_sub.pop()
    i = zx_sub.index(root)
    # 划分左右子树
    left_sub = zx_sub[0:i]
    right_sub = zx_sub[i+1:]
    # 子树重复以上过程继续拆分
    left = create_tree([c for c in hx_sub if c in left_sub], left_sub)
    right = create_tree([c for c in hx_sub if c in right_sub], right_sub)

    # 拼接子树
    root = Node(root)
    if left:
        root.left = left
    if right:
        root.right = right
    return root

# 后序遍历
def postorder_traversal(node):
    if not node:
        return
    postorder_traversal(node.left)
    postorder_traversal(node.right)
    print(node.data, end="")

# 层序遍历
def level_traversal(node):
    queue = [node]
    while queue:
        # 从队头取元素
        node = queue.pop(0)
        print(node.data, end="")
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)


# postorder_traversal(create_tree(hx, zx))
level_traversal(create_tree(hx, zx))