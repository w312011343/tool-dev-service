class Tree:
    def __init__(self):
        self.root = None
        self.queue = []
    # 构建二叉树
    def push(self, val):
        node = Node(val)

        def _do_push():
            if self.queue:
                if not self.queue[0].left:
                    self.queue[0].left = node
                elif not self.queue[0].right:
                    self.queue[0].right = node
                    self.queue.pop(0)
            else:
                self.root = node

        _do_push()
        self.queue.append(node)

    # 非叶子部分的后序遍历
    def postorderTraversal(self):
        result = []

        def _do_traversal(node):
            # 有左子树或右子树都不是叶子节点
            if not node or (not node.left and not node.right):
                return
            _do_traversal(node.left)
            _do_traversal(node.right)
            result.append(node.data)

        _do_traversal(self.root)
        # 只有一个节点的树，此节点认定为根节点（非叶子）。
        if self.root and not result:
            result.append(self.root.data)
        return result

datas = '1 2 3 4 5 6 7'
tree = Tree()
for c in datas:
    tree.push(c)

print(" ".join(tree.postorderTraversal()))