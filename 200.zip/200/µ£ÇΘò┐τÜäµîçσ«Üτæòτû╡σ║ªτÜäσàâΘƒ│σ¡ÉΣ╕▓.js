/**
 * 
 * 
 https://www.online1987.com/%e6%9c%80%e9%95%bf%e7%9a%84%e6%8c%87%e5%ae%9a%e7%91%95%e7%96%b5%e5%ba%a6%e7%9a%84%e5%85%83%e9%9f%b3%e5%ad%90%e4%b8%b2/

 
 【最长的指定瑕疵度的元音子串】

开头和结尾都是元音字母（aeiouAEIOU）的字符串为元音字符串，其中混杂的非元音字母数量为其瑕疵度。比如:

“a” 、 “aa”是元音字符串，其瑕疵度都为0
“aiur”不是元音字符串（结尾不是元音字符）
 “abira”是元音字符串，其瑕疵度为2
给定一个字符串，请找出指定瑕疵度的最长元音字符子串，并输出其长度，如果找不到满足条件的元音字符子串，输出0。

子串：字符串中任意个连续的字符组成的子序列称为该字符串的子串。

输入描述：

首行输入是一个整数，表示预期的瑕疵度flaw，取值范围[0, 65535]。

接下来一行是一个仅由字符a-z和A-Z组成的字符串，字符串长度(0, 65535]。

输出描述：

输出为一个整数，代表满足条件的元音字符子串的长度。

示例1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

0

asdbuiodevauufgh

输出

3

示例2  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

2

aeueo

输出

0


 */

let n = Number(readLine());
let str = readLine();
// let n = Number("3");
// let str = "kasdbuiodevauufgh";

let yuanyin = "aeiouAEIOU";
let len = str.length;
let list = []; //连续元音和辅音个数集合
let countYY = 0; //连续元音个数
let countFY = 0; //连续辅音个数

for (let i = 0; i < len; i++) {
  let temp = String(str.charAt(i));
  if (yuanyin.includes(temp)) {
    if (countFY != 0) {
      //辅音计算值有值，需要添加
      list.push(countFY);
      countFY = 0;
    }
    countYY++;
  } else {
    if (countYY != 0) {
      list.push(countYY);
      countYY = 0;
    }
    countFY++;
  }
  if (i == len - 1 && countYY != 0) {
    //因为开头结尾都必须是元音，所有剔除末尾的辅音
    list.push(countYY);
  }
}

if (!yuanyin.includes(String(str.charAt(0)))) {
  //因为开头结尾都必须是元音，所有剔除开头的辅音
  list.splice(0, 1);
}

let size = list.length;
let indexLeft = 0; //最左侧的元音索引
let max = 0;
let count = list[0]; //元音的个数
let xiaci = 0; //瑕疵的个数

if (n == 0) {
  //当瑕疵为0，需要单拎出来
  for (let i = 0; i < size; i += 2) {
    max = Math.max(max, list[i]);
  }
} else {
  for (let i = 1; i < size - 1; i += 2) {
    xiaci += list[i];
    count += list[i + 1]; //加上瑕疵右边的元音个数
    if (xiaci >= n) {
      if (xiaci == n) {
        //瑕疵度符合了，需要计算最大值
        max = Math.max(count + n, max);
      }
      count -= list[indexLeft]; //元音减去最左侧的元音个数
      xiaci -= list[indexLeft + 1]; //瑕疵减去最左侧的瑕疵个数
    }
  }
}

console.log(max);



bct = "aeiou"

while 1:
    try:
        k = int(input())
        nums = input()

        n = len(nums)
        nums = [1 if c in bct else 0 for c in nums]
        print(nums)
        max_ = 0
        i = 0
        j = min(k, n)
        while j < len(nums):
            count = nums[i:j].count(0)
            if count < k:
                j += 1
            elif count == k:
                max_ = max([j - i, max_])
                j += 1
            else:
                i += 1
        else:
            max_ = max([j - i, max_])

        print(max_)
    except Exception as e:
        break