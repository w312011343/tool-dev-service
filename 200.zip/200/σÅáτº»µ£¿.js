/**
 
https://www.online1987.com/%e5%8f%a0%e7%a7%af%e6%9c%a8/


有一堆长方体积木，它们的长度和宽度都相同，但长度不一。

小橙想把这堆积木叠成一面墙，墙的每层可以放一个积木，也可以将两个积木拼接起来，要求每层的长度相同。

若必须用完这些积木，叠成的墙最多为多少层？

如下是叠成的一面墙的图示，积木仅按宽和高所在的面进行拼接。



输入描述：

输入为一行，为各个积木的长度，数字为正整数，并由空格分隔。积木的数量和长度都不超过5000。

输出描述：

输出一个数字，为墙的最大层数，如果无法按要求叠成每层长度一致的墙，则输出-1。

输入

给定积木的长度，以空格分隔，例如：3 6 6 3。

输出

如果可以搭建，返回最大层数，如果不可以返回-1。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3 6 3 3 3

输出

3

解释：以 6 为底的墙，第一层为 6 ，第二层为 3 + 3，第三层 3 + 3。

示例2   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

9 9 9 5 3 2 2 2 2 2

输出

5

解释：

5+2+2=9

3+2+2+2=9

9,9,9

共五层

解题思路

 隐藏内容
背包问题，首先计算和sum，排序，选取最大的maxVal作为墙的第一层，

如果 sum % maxVal == 0，代表可以这样划分，

如果不可以则 maxVal += maxVal + nuns[i], 加上最小的。

可以化分的层数就为 cnt = sum / maxVal

背包容量为：sum /= cnt。
 */

let strings = readLine().split(" ");
//let strings = "4 5 3 6".split(" ");

let list = [];
let count = 0; //积木总长度
let len = strings.length;

for (let i = 0; i < len; i++) {
  let n = Number(strings[i]);
  count += n;
  list.push(n); //所有积木集合
}

list.sort();
let min = list[len - 1]; //最小宽度
let max = list[0] + list[len - 1]; //最大宽度（因为最多是两个积木拼接）
let res = -1;

for (let i = min; i <= max; i++) {
  if (count % i == 0) {
    let copyList = copyArr(list); //因为要对list进行多次操作，需要copy一下
    if (isSuccess(copyList, i)) {
      res = count / i;
      break;
    }
  }
}

console.log(res);

function copyArr(list) {
  let len = list.length;
  let copyList = [];

  for (let i = 0; i < len; i++) {
    copyList.push(list[i]);
  }

  return copyList;
}

function isSuccess(list, n) {
  let isTrue = true;

  while (list.length > 0 && isTrue) {
    let i = list.length - 1;
    if (n == list[i]) {
      list.splice(i, 1); //最长的一根积木符合要求则剔除进行下次循环
    } else if (n == list[i] + list[0]) {
      list.splice(i, 1); //最长一根跟最短一根积木之和符合要求则剔除两个积木进行下次循环
      list.splice(0, 1);
    } else {
      isTrue = false; //上面两个都不符合则表示无法完成一堵墙
    }
  }

  return isTrue;
}
