/**
 * 
 https://www.online1987.com/%e7%bb%9f%e8%ae%a1%e6%96%87%e6%9c%ac%e6%95%b0%e9%87%8f/

 【统计文本数量】

题目描述

有一个文件，包含以一定规则写作的文本，请统计文件中包含的文本数量。

规则如下：

1. 文本以”;”分隔，最后一条可以没有”;”，但空文本不能算语句，比如”COMMAND A; ;”只能算一条语句

注意，无字符/空白字符/制表符都算作”空”文本；

2. 文本可以跨行，比如下面，是一条文本，而不是三条；

COMMAND A

AND

COMMAND B;

3. 文本支持字符串，字符串为成对的单引号(‘)或者成对的双引号(“)，字符串可能出现用转义字符(\)处理的单双引号(“your input is\””)和转义字符本身，比如

COMMAND A “Say \”hello\””;

4. 支持注释，可以出现在字符串之外的任意位置注释以”–“开头，到换行结束，比如

 隐藏内容
COMMAND A; –this is comment

COMMAND –comment

A AND COMMAND B;

注意字符串内的”–“，不是注释。

输入描述：

文本文件

输出描述：

包含的文本数量

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

COMMAND TABLE IF EXISTS "UNITED STATE";
COMMAND A GREAT (
ID ADSAB,
download_length INTE-GER, -- test
file_name TEXT,
guid TEXT,
mime_type TEXT,
notifica-tionid INTEGER,
original_file_name TEXT,
pause_reason_type INTERGER,
resumable_flag INTERGER,
start_time INTERGER,
state INTERGER,
folder TEXT,
path TEXT,
total_length INTE-GER,
url TEXT
);
输出

2

 */
import sys

lines = []

def _add_lines(data):
    # 去除前后的空白字符
    data = data.strip()
    if data:
        lines.append(data)

line = ""
for _line in sys.stdin:
    # 替换文本中的 \" \' 为 #，减少不必要的判断
    _line = _line.replace('\\"', "#").replace("\\'", "#")
    start = 0
    end = 0
    while end < len(_line):
        # 跳过双引号字符串，中间的内容不做判断
        if _line[end] == '"' and '"' in _line[end+1:]:
            end += _line[end+1:].index('"') + 2
        # 跳过单引号字符串，中间的内容不做判断
        elif _line[end] == "'" and "'" in _line[end+1:]:
            end += _line[end+1:].index("'") + 2
        # 跳过注释直到换行结束
        elif _line[end] == "-":
            end = len(_line)
        # 一个有效的文本
        elif _line[end] == ";":
            end += 1
            line += _line[start: end]
            _add_lines(line)
            # 重新记录新的文本，一行中有多个 分号的情况
            start = end
            end += 1
            line = ""
        else:
            end += 1
    # 文本为结束，先记录下来
    line += _line[start: end]

# 最后一条可以没有”;”
_add_lines(line)

# print(lines)
print(len(lines))