/**
 * 
 https://www.online1987.com/%e7%8c%9c%e5%af%86%e7%a0%81/

 
 小杨申请了一个保密柜，但是他忘记了密码。只记得密码都是数字，而且所有数字都是不重复的。

请你根据他记住的数字范围和密码的最小数字数量，帮他算下有哪些可能的组合，规则如下：
1、输出的组合都是从可选的数字范围中选取的，且不能重复；
2、输出的密码数字要按照从小到大的顺序排列，密码组合需要按照字母顺序，从小到大的顺序排序。
3、输出的每一个组合的数字的数量要大于等于密码最小数字数量；
4、如果可能的组合为空，则返回“None”

输入描述:

1、输入的第一行是可能的密码数字列表，数字间以半角逗号分隔
2、输入的第二行是密码最小数字数量

输出描述:

可能的密码组合，每种组合显示成一行，每个组合内部的数字以半角逗号分隔，从小到大的顺序排列。
输出的组合间需要按照字典序排序。
比如：
2,3,4放到2,4的前面

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

2,3,4
2

输出

2,3
2,3,4
2,4
3,4

说明

最小密码数量是两个，可能有三种组合：
2,3
2,4
3,4

三个密码有一种：
2,3,4
 */

let strings = readLine().split(",");
//let strings = "2,0".split(",");

strings.sort();
let n = Number(readLine());

let len = strings.length;
var list = [];

for (let i = n; i <= len; i++) {
  combine(strings, i, new String(), 0);
}

list.sort();

if (list.length == 0) {
  console.log("None");
} else {
  list.forEach((v) => {
    let str = "";
    for (let i = 0; i < v.length; i++) {
      str += v.charAt(i);
      if (i != v.length - 1) {
        str += ",";
      }
    }
    console.log(str);
  });
}

function combine(str, n, res, index) {
  if (n == 0) {
    list.push(res);
  } else {
    for (let i = index; i < str.length; i++) {
      res += str[i];
      combine(str, n - 1, res, i + 1);
      res = res.substring(0, res.length - 1);
    }
  }
}
