/**
 
https://www.online1987.com/%e7%bb%84%e8%a3%85%e6%96%b0%e7%9a%84%e6%95%b0%e7%bb%84/

【组装新的数组】

给你一个整数M和数组N,N中的元素为连续整数，要求根据N中的元素组装成新的数组R，组装规则：

1.R中元素总和加起来等于M

2.R中的元素可以从N中重复选取

3.R中的元素最多只能有1个不在N中，且比N中的数字都要小（不能为负数）


输入描述

第一行输入是连续数组N，采用空格分隔
第二行输入数字M

输出描述

输出的是组装办法数量，int类型

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

2
5
输出

1
 */

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const lines = [];
rl.on("line", (line) => {
  lines.push(line);

  if (lines.length === 2) {
    const arr = lines[0].split(" ").map(Number);
    const m = lines[1] - 0;
    console.log(getResult(arr, m));
    lines.length = 0;
  }
});

function getResult(arr, m) {
  arr = arr.filter((val) => val <= m); // 只过滤出比m小的连续整数
  const min = arr[0];

  return dfs(arr, 0, 0, min, m, 0);
}

function dfs(arr, index, sum, min, m, count) {
  if (sum > m) {
    return count;
  }

  if (sum === m || (m - sum < min && m - sum > 0)) {
    return count + 1;
  }

  for (let i = index; i < arr.length; i++) {
    count = dfs(arr, i, sum + arr[i], min, m, count);
  }

  return count;
}
