/**
https://www.online1987.com/%e6%8e%8c%e6%8f%a1%e5%8d%95%e8%af%8d%e4%b8%aa%e6%95%b0/

题目描述

【掌握单词个数】

有一个字符串数组 words 和一个字符串 chars 。

假如可以用 chars 中的字母拼写出 words 中的某个“单词”（字符串），那么我们就认为你掌握了这个单词。

words 的字符仅由 a-z 英文小写字母组成，例如 “abc”
chars 由 a-z 英文小写字母和 “?” 组成。其中英文问号 “?” 表示万能字符，能够在拼写时当做任意一个英文字母。例如：“?” 可以当做 “a” 等字母。

注意：每次拼写时，chars 中的每个字母和万能字符都只能使用一次。

输出词汇表 words 中你掌握的所有单词的个数。没有掌握任何单词，则输出 0。


输入描述

第 1 行输入数组 words 的个数，记为 N。
从第 2 行开始到第 N+1 行一次输入数组 words 的每个字符串元素。
第 N+2 行输入字符串 chars。

输出描述

输出一个整数，表示词汇表 words 中你掌握的单词个数。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

4
cat
bt
hat
tree
atach
输出

6



 */

const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;

void (async function () {
  class TreeNode {
    constructor(curDicName, father) {
      this.curDicName = curDicName;
      this.father = father;
      this.children = {};
    }
  }

  class Tree {
    constructor() {
      // root是根目录，根目录 / 作为初始目录
      this.root = new TreeNode("/", null);
      // cur用于指向当前正在操作的目录
      this.cur = this.root;
    }

    mkdir(dicName) {
      // mkdir 目录名称，如 mkdir abc 为在当前目录创建abc目录，如果已存在同名目录则不执行任何操作
      if (!this.cur.children[dicName]) {
        this.cur.children[dicName] = new TreeNode(dicName + "/", this.cur);
      }
    }

    cd(dicName) {
      if (dicName == "..") {
        // cd .. 为返回上级目录，如果目录不存在则不执行任何操作
        if (this.cur.father != null) {
          // cur 变更指向上级目录
          this.cur = this.cur.father;
        }
      } else {
        // cd 目录名称，如 cd abc 为进入abc目录，如果目录不存在则不执行任何操作
        if (this.cur.children[dicName]) {
          // cur 变更指向下级目录
          this.cur = this.cur.children[dicName];
        }
      }
    }

    pwd() {
      // 输出当前路径字符串
      const arr = [];

      // 倒序路径，即不停向上找父目录
      let cur = this.cur;
      while (cur != null) {
        arr.push(cur.curDicName);
        cur = cur.father;
      }

      // 反转后拼接
      return arr.reverse().join("");
    }
  }

  // 初始化目录结构
  const tree = new Tree();
  // 记录最后一条命令的输出
  let lastCommandOutPut = "";

  outer: while (true) {
    try {
      const line = await readline();

      // 本地测试解开此行
      // if (line == "") break;

      const tmp = line.split(" ");
      const cmd_key = tmp[0];

      if (cmd_key == "pwd") {
        // pwd 命令不需要参数
        if (tmp.length != 1) continue;
        lastCommandOutPut = tree.pwd();
      } else if (cmd_key == "mkdir" || cmd_key == "cd") {
        // 约束：mkdir 和 cd 命令的参数仅支持单个目录，如：mkdir abc 和 cd abc
        if (tmp.length != 2) continue;

        // 目录名
        const cmd_val = tmp[1];

        // 目录名约束校验
        // 约束：目录名称仅支持小写字母
        // 约束：不支持嵌套路径和绝对路径，如 mkdir abc/efg，cd abc/efg，mkdir /abc/efg，cd /abc/efg 是不支持的。
        // 关于嵌套路径和绝对路径，我简单理解就是cmd_val含有'/'字符，可以被小写字母判断涵盖住
        for (let c of cmd_val) {
          if (c < "a" || c > "z") continue outer;
        }

        if (cmd_key == "mkdir") {
          tree.mkdir(cmd_val);
          // 题目进要求输出最后一个命令的运行结果，因此，对于无输出的命令，我认为需要覆盖掉前面的命令的输出结果
          lastCommandOutPut = "";
        } else {
          tree.cd(cmd_val);
          // 题目进要求输出最后一个命令的运行结果，因此，对于无输出的命令，我认为需要覆盖掉前面的命令的输出结果
          lastCommandOutPut = "";
        }
      }
    } catch (e) {
      break;
    }
  }

  console.log(lastCommandOutPut);
})();
