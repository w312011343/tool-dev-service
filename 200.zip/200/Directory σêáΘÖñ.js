/**
 * 
 
https://www.online1987.com/directory-%e5%88%a0%e9%99%a4/

【Directory 删除】

某文件系统中有 N 个目录，每个目录都一个独一无二的 ID。

每个目录只有一个父目录，但每个父目录下可以有零个或者多个子目录，目录结构呈树状结构。

假设，根目录的 ID 为 0，且根目录没有父目录，其他所有目录的 ID 用唯一的正整数表示，并统一编号。

现给定目录 ID 和其父目录 ID 的对应父子关系表[子目录 ID，父目录 ID]，以及一个待删除的目录 ID，请计算并返回一个 ID 序列，表示因为删除指定目录后剩下的所有目录，返回的ID 序列以递增序输出。

注意

1、被删除的目录或文件编号一定在输入的 ID 序列中；

2、当一个目录删除时，它所有的子目录都会被删除。

输入描述

输入的第一行为父子关系表的长度 m；

接下来的 m 行为 m 个父子关系对；

最后一行为待删除的 ID。

序列中的元素以空格分割，参见样例。

输出描述

输出一个序列，表示因为删除指定目录后，剩余的目录 ID。

示例 1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5
8 6
10 8
6 0
20 8
2 6
8
全选代码
复制
输出

2 6
全选代码
复制
目录结构如下所示：

6

/ |

2 8

删除目录8，同时它的子目录10也被删除，剩余2和6两个目录。
 */

let n = Number(readLine());
//let n = Number("5");

let list = [];
var res = "";
var afterDelete = [];
//let test = ["8 6","10 8","6 0","20 8","2 6"]

for (let i = 0; i < n; i++) {
  let ints = readLine()
    .split(" ")
    .map((i) => parseInt(i));
  //let ints = test[i].split(" ").map(i=>parseInt(i));
  if (afterDelete.indexOf(ints[0]) == -1) {
    afterDelete.push(ints[0]);
  }
  if (afterDelete.indexOf(ints[1]) == -1) {
    afterDelete.push(ints[1]);
  }
  list.push(ints); //将目录关系表以数组的方式存储在集合中
}

let id = Number(readLine());
//let id = Number("8");
let index = afterDelete.indexOf(id);
afterDelete.splice(index, 1);

deleteMenu(list, id);

afterDelete.sort();

for (let i = 0; i < afterDelete.length; i++) {
  if (afterDelete[i] == 0) {
    continue;
  }
  res += afterDelete[i];
  if (i != afterDelete.length - 1) {
    res += " ";
  }
}

console.log(res);

/**
 *
 * @param list  目录关系表集合
 * @param n     需要剔除的目录
 */
function deleteMenu(list, n) {
  for (let i = 0; i < list.length; i++) {
    if (list[i][1] == n) {
      //找到需要剔除的目录的关系数组
      let index = afterDelete.indexOf(list[i][0]);
      afterDelete.splice(index, 1);
      delete (list, list[i][0]);
    }
  }
}



import java.util.*;

public class Directory {

    public static TreeSet<Integer> treeSet = new TreeSet<>();   //自动排序去重

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        List<int[]> list = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            int[] ints = new int[2];
            ints[0] = sc.nextInt();
            ints[1] = sc.nextInt();
            treeSet.add(ints[0]);
            treeSet.add(ints[1]);
            list.add(ints); //将目录关系表以数组的方式存储在集合中
        }

        int id = sc.nextInt();
        treeSet.remove(id);
        delete(list, id);

        treeSet.forEach((v) -> {
            if (v != 0) System.out.print(v + " ");   //将根目录去除
        });

    }

    /**
     * @param list 目录关系表集合
     * @param n    需要剔除的目录
     */
    public static void delete(List<int[]> list, int n) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i)[1] == n) {    //找到需要剔除的目录的关系数组
                treeSet.remove(list.get(i)[0]);
                delete(list, list.get(i)[0]);
            }
        }
    }
}
