/**
https://www.online1987.com/%e6%a8%a1%e6%8b%9f%e7%9b%ae%e5%bd%95%e7%ae%a1%e7%90%86%e5%8a%9f%e8%83%bd/ 

题目描述

【模拟目录管理功能】

实现一个模拟目录管理功能的软件，输入一个命令序列，输出最后一条命令运行结果。

支持命令：

创建目录命令：mkdir 目录名称，如 mkdir abc 为在当前目录创建abc目录，如果已存在同名目录则不执行任何操作。此命令无输出。
进入目录命令：cd 目录名称，如 cd abc 为进入abc目录，特别地，cd .. 为返回上级目录，如果目录不存在则不执行任何操作。此命令无输出。
查看当前所在路径命令：pwd，输出当前路径字符串。

目录名称仅支持小写字母；mkdir 和 cd 命令的参数仅支持单个目录，如：mkdir abc 和 cd abc；不支持嵌套路径和绝对路径，如 mkdir abc/efg，cd abc/efg，mkdir /abc/efg，cd /abc/efg 是不支持的。
目录符号为/，根目录/作为初始目录。
任何不符合上述定义的无效命令不做任何处理并且无输出。

输入描述

输入 N 行字符串，每一行字符串是一条命令。

输出描述

输出最后一条命令运行结果字符串。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

mkdir abc
cd abc
pwd
输出

/abc/

 */

const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;

void (async function () {
  class TreeNode {
    constructor(curDicName, father) {
      this.curDicName = curDicName;
      this.father = father;
      this.children = {};
    }
  }

  class Tree {
    constructor() {
      // root是根目录，根目录 / 作为初始目录
      this.root = new TreeNode("/", null);
      // cur用于指向当前正在操作的目录
      this.cur = this.root;
    }

    mkdir(dicName) {
      // mkdir 目录名称，如 mkdir abc 为在当前目录创建abc目录，如果已存在同名目录则不执行任何操作
      if (!this.cur.children[dicName]) {
        this.cur.children[dicName] = new TreeNode(dicName + "/", this.cur);
      }
    }

    cd(dicName) {
      if (dicName == "..") {
        // cd .. 为返回上级目录，如果目录不存在则不执行任何操作
        if (this.cur.father != null) {
          // cur 变更指向上级目录
          this.cur = this.cur.father;
        }
      } else {
        // cd 目录名称，如 cd abc 为进入abc目录，如果目录不存在则不执行任何操作
        if (this.cur.children[dicName]) {
          // cur 变更指向下级目录
          this.cur = this.cur.children[dicName];
        }
      }
    }

    pwd() {
      // 输出当前路径字符串
      const arr = [];

      // 倒序路径，即不停向上找父目录
      let cur = this.cur;
      while (cur != null) {
        arr.push(cur.curDicName);
        cur = cur.father;
      }

      // 反转后拼接
      return arr.reverse().join("");
    }
  }

  // 初始化目录结构
  const tree = new Tree();
  // 记录最后一条命令的输出
  let lastCommandOutPut = "";

  outer: while (true) {
    try {
      const line = await readline();

      // 本地测试解开此行
      // if (line == "") break;

      const tmp = line.split(" ");
      const cmd_key = tmp[0];

      if (cmd_key == "pwd") {
        // pwd 命令不需要参数
        if (tmp.length != 1) continue;
        lastCommandOutPut = tree.pwd();
      } else if (cmd_key == "mkdir" || cmd_key == "cd") {
        // 约束：mkdir 和 cd 命令的参数仅支持单个目录，如：mkdir abc 和 cd abc
        if (tmp.length != 2) continue;

        // 目录名
        const cmd_val = tmp[1];

        // 目录名约束校验
        // 约束：目录名称仅支持小写字母
        // 约束：不支持嵌套路径和绝对路径，如 mkdir abc/efg，cd abc/efg，mkdir /abc/efg，cd /abc/efg 是不支持的。
        // 关于嵌套路径和绝对路径，我简单理解就是cmd_val含有'/'字符，可以被小写字母判断涵盖住
        for (let c of cmd_val) {
          if (c < "a" || c > "z") continue outer;
        }

        if (cmd_key == "mkdir") {
          tree.mkdir(cmd_val);
          // 题目进要求输出最后一个命令的运行结果，因此，对于无输出的命令，我认为需要覆盖掉前面的命令的输出结果
          lastCommandOutPut = "";
        } else {
          tree.cd(cmd_val);
          // 题目进要求输出最后一个命令的运行结果，因此，对于无输出的命令，我认为需要覆盖掉前面的命令的输出结果
          lastCommandOutPut = "";
        }
      }
    } catch (e) {
      break;
    }
  }

  console.log(lastCommandOutPut);
})();
