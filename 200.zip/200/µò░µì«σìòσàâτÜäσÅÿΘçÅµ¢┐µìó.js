/**
https://www.online1987.com/%e6%95%b0%e6%8d%ae%e5%8d%95%e5%85%83%e7%9a%84%e5%8f%98%e9%87%8f%e6%9b%bf%e6%8d%a2/ 
题目描述


【数据单元的变量替换】

将一个csv格式的数据文件中包含有单元格引用的内容替换为对应单元格内容的实际值。

Comma seprated values (CSV)逗号分隔值，csv格式的数据文件使用逗号作为分隔符将各单位的内容进行分隔。

输入描述

1.输入只有一行数据,用逗号分隔每个单元格,行尾没有逗号。最多26个单元格，对应编号A-Z。

2.每个单元格的内容包含字母和数字，以及使用<>分隔的单元格引用，例如:<A>表示引用第一个单元的值。

输入描述

1.输入只有一行数据,用逗号分隔每个单元格,行尾没有逗号。最多26个单元格,对应编号A-Z。
2.每个单元格的内容包含字母和数字,以及使用<>分隔的单元格引用,例如:<A>表示引用第一个单元的值。
3.每个单元格的内容,在替换前和替换后均不超过100个字符。
5.引用单元格的位置不受限制,运行排在后面的单元格被排在前面的单元格引用。
6.不存在循环引用的情况,比如下面这种场景是不存在的:
A单元格:aCd<B>8u
B单元格:kAy<A>dzqo
7.不存在多重<>的情况,一个单元格只能引用一个其他单元格。比如下面这种场景是不存在的:
A单元格:aCd8u
B单元格:kAydzqo
C单元格:y<<A><B>>d

输出描述

输出所有单元格展开的内容,单元格之间用逗号分隔。处理过程中出现错误时,输出字符串”-1″表示出错。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

1,2<A>00
输出

1,2100
说明

第二个单元中有对A单元的引用,A单元格的值为1,替换时,将A单元的内容替代<A>的位置,并和其他内容合并。

 */
const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;

void (async function () {
  const s = await readline();
  console.log(getResult(s));
})();

function isOperator(c) {
  return c == "+" || c == "-" || c == "*" || c == "/";
}

function isValidExpBeginChar(c) {
  // 这里有个疑问："+1"，"-1" 这种算不算合法表达式？我理解是算的, 这里的+、-可以理解为正负号
  // 因此合法表达式开头字符可以是：数字0-9、+、-
  // 如果实际考试发现不对，则：合法表达式开头字符只能是数字
  return (c >= "0" && c <= "9") || c == "+" || c == "-";
}

function getResult(s) {
  // 记录最长合法表达式
  let express = "";
  // 记录最长的合法表达式的长度
  let maxLen = 0;

  // 简单数学表达式只能包含:数字0-9 ，符号+、-、*、/
  // 因此这里直接按照 非（0-9和+-*/）字符 进行分割
  const subs = s.split(/[^0-9+\-*/]/);

  for (let sub of subs) {
    // 通过l,r双指针寻找sub串中合法表达式子串的范围
    let l = 0;

    // 找合法表达式子串的开头位置
    while (l < sub.length && !isValidExpBeginChar(sub[l])) {
      l++;
    }

    // 如果开头位置已经越界，则sub串中没有合法表达式子串
    if (l == sub.length) continue;

    // 这里在sub串尾巴后面拼接"++", 作用是免去了收尾处理
    // 在sub串尾巴后面拼接"++"不会影响sub串中存在的合法表达式子串的长度
    sub += "++";

    // r 指针扫描合法表达式子串
    let r = l + 1;
    while (r < sub.length) {
      // 如果r，r-1 位置都是运算符，则出现连续符号，那么合法表达式的扫描被打断
      if (isOperator(sub[r]) && isOperator(sub[r - 1])) {
        // 合法表达式子串范围 [l, r-1) ，注意范围是左闭右开
        // 合法表达式子串的长度
        const len = r - 1 - l;

        // 返回最长的合法表达式
        // 如果有多个长度一样的，请返回第一个表达式的结果
        if (len > maxLen) {
          // 如果合法表达式中存在 除0 运算，则视为不合法
          // 此时需要将表达式拆分，比如表达式为：1+2*3-4+5/0-6+7*8/9+10，就可以拆分为：1+2*3-4+5 和 0-6+7*8/9+10
          const ts = sub
            .slice(l, r - 1)
            .replaceAll("/0", " 0")
            .split(" ");

          for (let tmp of ts) {
            if (tmp.length > maxLen) {
              maxLen = tmp.length;
              express = tmp;
            }
          }
        }

        // 继续向后找新的合法表达式的开头位置，让l从r位置开始找
        l = r;

        while (l < sub.length && !isValidExpBeginChar(sub[l])) {
          l++;
        }

        r = l;
      }

      r++;
    }
  }

  if (maxLen > 0) {
    // 如果最长合法表达式的长度 > 0，则计算对于合法表达式的结果
    return calcExpStr(express);
  } else {
    // 如果最长合法表达式的长度 == 0, 则没有合法表达式，直接返回 0
    return 0;
  }
}

function calcExpStr(expStr) {
  // 这里在合法表达式串尾巴后面拼接"+0"是为了避免写收尾逻辑代码
  expStr += "+0";

  /*
   * 对于一个合法表达式串，比如：1+2*3-5+10/2
   * 为了实现表达式先乘除，后加减的运算规则，我们应该将表达式进行分块：
   * 1、2*3、-5、10/2
   * 即遍历表达式字符串时
   * 如果扫描到+、-号，则其前面的操作数独立成为一块
   * 如果扫描到*、/号，则其前面的操作数不能独立，需要和*、/号后面的操作数组合为一块
   * 另外操作数分为两部分：系数、值
   * 上面表达式扫描到-号时，则定义后面操作数的系数为-1，扫描到5时，则定义操作数的值为5，再扫描到+号时，则前面操作数-5的完成统计，结果为-1*5
   */

  // 记录表达式中各块的操作数
  const stack = [];

  // 临时缓存操作数的值部分的容器
  let numStr = [];

  // 如果合法表达式串开头是+、-号，那么给容器加入一个默认值0
  if (isOperator(expStr[0])) {
    numStr.push(0);
  }

  // 操作数的系数部分，默认为1
  let num_coef = 1;

  // 前面是否发生了除法
  let beforeIsDiv = false;

  for (let i = 0; i < expStr.length; i++) {
    const c = expStr[i];

    if (c >= "0" && c <= "9") {
      numStr.push(c);
    } else {
      // 如果扫描到的字符c是运算符，那么该运算符打断了前面操作数的扫描，前面操作数 = 系数 * 值
      const num = num_coef * parseInt(numStr.join(""));

      if (beforeIsDiv) {
        // 如果操作数num前面发生了除法，那么stack栈顶记录的就是被除数，num本身就是除数，我们需要计算此时 被除数 / 除数 的结果，并将结果重新加入栈中
        stack.push(Math.floor(stack.pop() / num));
      } else {
        // 如果操作数num前面没有发生除法，那么操作数独立成块，直接入栈
        stack.push(num);
      }

      beforeIsDiv = false;

      // 清空操作数的值记录的容器
      numStr.length = 0;

      switch (c) {
        case "+":
          // 如果运算符是加法，则后一个操作数的系数为1
          num_coef = 1;
          break;
        case "-":
          // 如果运算符是减法，则后一个操作数的系数为-1
          num_coef = -1;
          break;
        case "*":
          // 如果运算符是乘法，则后一个操作数的系数为栈顶值，比如2*3，其中2可以当作3的系数
          num_coef = stack.pop();
          break;
        case "/":
          // 如果运算符是除法，则后一个操作数将作为除数，比如10/2，本题不会出现10/-2的情况，因此除数的系数一定是1
          num_coef = 1;
          // 标记一下发生了除法
          beforeIsDiv = true;
          break;
      }
    }
  }

  // 表达式分块后，每一块独立计算，所有块的和就是表达式的结果
  return stack.reduce((a, b) => a + b);
}
