/**
 * 
 https://www.online1987.com/%e6%9c%80%e5%b0%8f%e4%bc%a0%e8%be%93%e6%97%b6%e5%bb%b6-2/
 
 【最小传输时延】

有M*N的节点矩阵，每个节点可以向8个方向（上、下、左、右及四个斜线方向）转发数据包，每个节点转发时会消耗固定时延，

连续两个相同时延可以减少一个时延值（即当有K个相同时延的节点连续转发时可以减少K- 1个时延值），

求左上角（0，0）开始转发数据包到右下角（M-1，N- 1）并转发出的最短时延。

输入描述

第一行两个数字，M、N，接下来有M行，每行有N个数据，表示M* N的矩阵。

输出描述

最短时延值。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

3 3
0 2 2
1 2 1
2 2 1

输出

3

示例2   输入输出示例仅供调试，后台判题数据一般不包含示例

3 3
2 2 2
2 2 2
2 2 2

输出：

4

（2 + 2 + 2 -（3-1))


 */

if __name__ == "__main__":
    m, n = map(int, input().split())
    grid = []
    for i in range(m):
        grid.append(list(map(int, input().split())))
    from heapq import *


    def search(grid):
        visited = set()
        p = [(grid[0][0], 0, 0, grid[0][0])]
        visited.add((0, 0))
        heapify(p)
        while p:
            t, i, j, pre = heappop(p)
            if i == len(grid) - 1 and j == len(grid[0]) - 1:
                return t
            for i_new, j_new in [(i - 1, j - 1), (i - 1, j), (i, j - 1), (i + 1, j + 1), (i + 1, j), (i, j + 1),
                                 (i - 1, j + 1), (i + 1, j - 1)]:
                if 0 <= i_new < len(grid) and 0 <= j_new < len(grid[0]) and (i_new, j_new) not in visited:
                    visited.add((i_new, j_new))
                    if pre == grid[i_new][j_new]:
                        heappush(p, (t + grid[i_new][j_new] - 1, i_new, j_new, grid[i_new][j_new]))
                    else:
                        heappush(p, (t + grid[i_new][j_new], i_new, j_new, grid[i_new][j_new]))


    out = search(grid)
    print(out)