/**
 * 
 https://www.online1987.com/%e6%9c%80%e5%b0%8f%e4%bc%a0%e8%be%93%e6%97%b6%e5%bb%b6/
 
 题目描述

某通信网络中有N个网络结点，用1到N进行标识。网络通过一个有向无环图表示，其中图的边的值表示结点之间的消息传递时延。
现给定相连节点之间的时延列表times[i]={u，v，w}，其中u表示源结点，v表示目的结点，w表示u和v之间的消息传递时延。
请计算给定源结点到目的结点的最小传输时延，如果目的结点不可达，返回-1。
注：

N的取值范围为[1，100];
时延列表times的长度不超过6000，且 1 <= u,v <= N，0 <= w <= 100;
输入描述



输入的第一行为两个正整数，分别表示网络结点的个数N，以及时延列表的长度M，用空格分隔；
接下来的M行为两个结点间的时延列表[u v w];
输入的最后一行为两个正整数，分别表示源结点和目的结点。
输出描述

见题目要求
输入

3 3

1 2 11

2 3 13

1 3 50

1 3

输出

24
 */

var N = Number(readLine());
let M = Number(readLine());
// var N = Number("3");
// let M = Number("3");

var ints = Array(N)
  .fill()
  .map(() => Array(N).fill(0)); //新建全为0的二维数组
var min = Number.MAX_VALUE;
var list = []; //存放遍历过的节点
// let test = ["1 2 11",
//            "2 3 13",
//            "1 3 50"];

/**
 * 根据输入值构建二维数组
 * 数组下标从0开始，需要-1
 */
for (let i = 0; i < M; i++) {
  let str = readLine()
    .spit(" ")
    .map((i) => parseInt(i));
  //let str = test[i].split(" ").map(i=>parseInt(i));
  ints[str[0] - 1][str[1] - 1] = str[2];
  ints[str[1] - 1][str[0] - 1] = str[2];
}

let start = Number(readLine()) - 1; //源节点
var end = Number(readLine()) - 1; //目的节点
// let start = Number("1")-1; //源节点
// var end = Number("3")-1;   //目的节点

qiushiyan(start, 0);

console.log(min);

/**
 * @param start 源节点
 * @param count 时延总和
 */
function qiushiyan(start, count) {
  for (let i = 0; i < N; i++) {
    let num = ints[start][i];
    if (num != 0 && list.indexOf(i) == -1) {
      if (i == end) {
        //目的节点到了，说明可以连通了
        min = Math.min(min, count + num);
      } else {
        list.push(i); //每遍历一个节点都需要记录，防止进入死循环
        qiushiyan(i, count + num);
      }
    }
  }
}
