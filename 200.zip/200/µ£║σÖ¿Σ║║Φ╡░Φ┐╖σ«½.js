/**
 * 
 https://www.online1987.com/%e6%9c%ba%e5%99%a8%e4%ba%ba%e8%b5%b0%e8%bf%b7%e5%ae%ab/

 
 【机器人走迷宫】

机器人走一个迷宫，给出迷宫的x和y(x*y的迷宫)并且迷宫中有障碍物,输入k表示障碍物有k个，并且会将障碍物的坐标挨个输入。

机器人从0,0的位置走到x,y的位置并且只能向x,y增加的方向走，不能回退，

如代码类注释展示的样子，#表示可以走的方格，0代表障碍，机器人从0,0的位置只能向下或者向前走到出口，

其中会有不可达方格和陷阱方格。

不可达方格为第四行前三个，该机器人在行走路径上不可能走到的方格，陷阱方格如第一行最后两个，走进之后则不能抵达终点。

要求: 输出陷阱和不可达方格方格数量。


 */

// let input = readline().split(" ").map(Number);
// let n = Number(readline());
let input = "6 4".split(" ").map(Number);
let n = Number("5");

var x = input[0];
var y = input[1];
var room = Array(x)
  .fill()
  .map(() => Array(y).fill(0));

let test = ["0 2", "1 2", "2 2", "4 2", "5 2"];

while (n-- > 0) {
  //input = readline().split(" ").map(Number);
  input = test[4 - n].split(" ").map(Number);
  room[input[0]][input[1]] = -1; //-1表示有墻
}

out(0, 0);

let countA = 0,
  countB = 0;
for (let i = 0; i < x; i++) {
  for (let j = 0; j < y; j++) {
    if (room[i][j] == 2) {
      //2表示死路
      countB++;
    } else if (room[i][j] == 0) {
      //表示沒有走过的路，即无法到达的地方
      countA++;
    }
  }
}

console.log(countB + " " + countA);

function out(i, j) {
  if (i == x - 1 && j == y - 1) {
    //表示到达终点，也就是出口
    room[i][j] = 1; //终点可以到达，设置为1
    return;
  }
  if (room[i][j] != 0) {
    //已经确定了不需要再次确定
    return;
  }
  if (i < x - 1) {
    //没有到达x轴边界，继续探索
    out(i + 1, j);
  }
  if (j < y - 1) {
    //没有到达y轴边界，继续探索
    out(i, j + 1);
  }
  if (i == x - 1 || j == y - 1) {
    //到达边界
    if (i == x - 1 && j < y - 1 && room[i][j + 1] != 1) {
      room[i][j] = 2; //到达x轴边界，上边是不可到达的，则此格为死路
    } else if (j == y - 1 && i < x - 1 && room[i + 1][j] != 1) {
      room[i][j] = 2; //到达y轴边界，右边是不可到达的，则此格为死路
    } else {
      room[i][j] = 1; //可以到达的格子
    }
  } else if (room[i][j + 1] != 1 && room[i + 1][j] != 1) {
    room[i][j] = 2; //右边和上边都是不可到达，则此格为死路
  } else {
    room[i][j] = 1; //可到达的格子
  }
}
