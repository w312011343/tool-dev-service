/**
 * 
 https://www.online1987.com/%e5%ad%97%e7%ac%a6%e4%b8%b2%e5%8c%b9%e9%85%8d/


 【字符串匹配】

给你一个字符串数组（每个字符串均由小写字母组成）和一个字符规律（由小写字母和.和*组成），识别数组中哪些字符串可以匹配到字符规律上。

‘.’ 匹配任意单个字符，’*’ 匹配零个或多个前面的那一个元素，所谓匹配，是要涵盖整个字符串的，而不是部分字符串。

输入描述

第一行为空格分割的多个字符串，1<单个字符串长度<100，0，1<字符串个数<100

第二行为字符规律，1<字符串个数<100

第二行为字符规律，1<=字符规律长度<=50

不需要考虑异常场景。

输出描述

匹配的字符串在数组中的下标（从0开始），多个匹配时下标升序并用,分割，若均不匹配输出-1

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

ab aab

.*

输出

0,1

示例2 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

ab abc bsd

.*

输出

0,1,2

示例3 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

avd adb sss as

adb

输出

1



 */


import re

while 1:
    try:
        nums = input().split()
        pattern = input()
        ret = []
        for index, w in enumerate(nums):
            if re.match(pattern, w):
                ret.append(str(index))
        if ret:
            print(",".join(ret))
        else:
            print("-1")
    except Exception as e:
        break

        import java.util.Scanner;

        public class StringMatch {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                String input = scanner.nextLine();
                String[] StringArray = input.split(" ");
                String line = scanner.nextLine();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < StringArray.length; i++) {
                    if (judge(line, StringArray[i])) {
                        sb.append(String.valueOf(i)).append(",");
                    }
                }
                System.out.println(sb.substring(0, sb.length() - 1));
            }
        
            public static boolean judge(String str1, String str2) {
        
                int i = 0, j = 0;
                while (i < str1.length() && j < str2.length()) {
                    if (str1.charAt(i) == str2.charAt(j) || str1.charAt(i) == '.') {
                        i++;
                        j++;
                        continue;
                    }
        
                    if (str1.charAt(i) != '.' && str1.charAt(i) != '*' && str1.charAt(i) != str2.charAt(j))    {
                        return false;
                    }
                    if (str1.charAt(i) == '*') {
                        i++;
                        if (i >= str1.length())
                            return true;
                        else {
                            if (str1.charAt(i) == str2.charAt(j))
                                j++;
                            while (str1.charAt(i) != str2.charAt(j)) {
                                if (str1.charAt(i) == '.') {
                                    j++;
                                    break;
                                } else {
                                    j++;
                                    if (j >= str2.length())
                                        return false;
                                }
                            }
                        }
                    }
                }
                return true;
            }
        }