/**
 https://www.online1987.com/%e5%91%a8%e6%9c%ab%e7%88%ac%e5%b1%b1/
 【周末爬山】

周末小明准备去爬山锻炼，0代表平地，山的高度使用1到9来表示、小明每次爬山或下山高度只能相差k及k以内，每次只能上下左右一个方向上移动一格，小明从左上角(0,0)位置出发。

输入描述

第一行输入m n k(空格分隔)，代表m*n的二维山地图，K为小明每次爬山或下山高度差的最大值。
然后接下来输入山地图，一共m行n列，均以空格分隔。
取值范围：0<m<=500,0<n<=500,0<K<5

输出描述

请问小明能爬到的最高峰多高，到该最高峰的最短步数，输出以空格分隔。
同高度的山峰输出较短步数。如果没有可以爬的山峰则高度和步数都返回0。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5 4 1
0 1 2 0
1 0 0 0
1 0 1 2
1 3 1 0
0 0 0 9
输出

2 2
说明

输出解读：根据山地图可知，能爬到的最高峰在(0,2)位置，高度为2，最短路径为(0,0)-(0,1)-(0,2)，最短步数为2。

示例2 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5 4 3
0 0 0 0
0 0 0 0
0 9 0 0
0 0 0 0
0 0 0 9
输出

0 0
说明

输出解读：根据山地图可知，每次爬山距离3，无法爬到山峰上，步数为0。
 */
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const lines = [];
let m, n, k;
let matrix;
rl.on("line", (line) => {
  lines.push(line);

  if (lines.length == 1) {
    [m, n, k] = lines[0].split(" ").map(Number);
  }

  if (m && lines.length == m + 1) {
    lines.shift();
    matrix = lines.map((s) => s.split(" ").map(Number));
    console.log(getResult());
    lines.length = 0;
  }
});

function getResult() {
  // key表示山峰高度，value表示到达此山峰高度的最短步数
  const minStepToHeight = {};
  // 到达matrix[0][0]高度的山峰，最短步数是0
  minStepToHeight[matrix[0][0]] = 0;

  // 广搜
  bfs(minStepToHeight);

  // 取得最大高度
  const maxHeight = Math.max(...Object.keys(minStepToHeight));
  // 取得最大高度对应的最短步数
  const minStep = minStepToHeight[maxHeight];

  return maxHeight + " " + minStep;
}

const offsets = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];

function bfs(minStepToHeight) {
  // 广搜队列
  let queue = [];
  // 访问记录
  const visited = new Array(m).fill(0).map(() => new Array(n).fill(false));

  // 首先是(0,0)位置进入队列，且被标记为访问过
  queue.push([0, 0]);
  visited[0][0] = true;

  // 此时消耗步数为0
  let step = 0;

  while (queue.length > 0) {
    // 这里没有用queue.removeFirst来控制广搜，而是使用newQueue来控制广搜，因为这样更方便操作step
    const newQueue = [];
    step++;

    // 遍历同一层的所有节点
    for (let [x, y] of queue) {
      const lastHeight = matrix[x][y];

      // 四个方向位置
      for (let [offsetX, offsetY] of offsets) {
        const newX = x + offsetX;
        const newY = y + offsetY;

        // 新位置越界则无法继续广搜
        if (newX < 0 || newX >= m || newY < 0 || newY >= n) continue;

        // 新位置已访问过，则无需重复广搜
        if (visited[newX][newY]) continue;

        const curHeight = matrix[newX][newY];

        // 前后位置高度差在k以内, 则可以进入新位置
        if (Math.abs(curHeight - lastHeight) <= k) {
          // 标记新位置已访问
          visited[newX][newY] = true;

          // 如果此时到达新位置高度的步数step更小，则更新对应高度的最小步数
          if (
            minStepToHeight[curHeight] == undefined ||
            minStepToHeight[curHeight] > step
          ) {
            minStepToHeight[curHeight] = step;
          }

          // 新位置加入下一层广搜队列
          newQueue.push([newX, newY]);
        }
      }
    }

    queue = newQueue;
  }
}
