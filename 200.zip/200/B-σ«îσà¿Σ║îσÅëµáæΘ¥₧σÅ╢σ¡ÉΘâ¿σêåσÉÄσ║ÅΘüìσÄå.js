/**
 * 
 https://www.online1987.com/%e5%ae%8c%e5%85%a8%e4%ba%8c%e5%8f%89%e6%a0%91%e9%9d%9e%e5%8f%b6%e5%ad%90%e9%83%a8%e5%88%86%e5%90%8e%e5%ba%8f%e9%81%8d%e5%8e%86-2/
  题目描述

给定一个以顺序储存结构存储整数值的完全二叉树序列（最多1000个整数），请找出此完全二叉树的所有非叶子节点部分，然后采用后序遍历方式将此部分树（不包含叶子）输出。

1、只有一个节点的树，此节点认定为根节点（非叶子）。

2、此完全二叉树并非满二叉树，可能存在倒数第二层出现叶子或者无右叶子的情况

其他说明：二叉树的后序遍历是基于根来说的，遍历顺序为：左-右-根

输入描述:

一个通过空格分割的整数序列字符串
输出描述:

非叶子部分树结构
示例1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

1 2 3 4 5 6 7

输出

2 3 1

说明

找到非叶子部分树结构，然后采用后序遍历输出。

备注:

输出数字以空格分隔
 */

class Node {
  constructor(value, left, right) {
    this.value = value;
    this.left = left;
    this.right = right;
  }
}

class Tree {
  constructor() {
    this.root = null;
    this.queen = [];
    this.result = [];
  }
  push(value) {
    let node = new Node(value);
    if (this.queen.length) {
      if (!this.queen[0].left) {
        this.queen[0].left = node;
      } else if (!this.queen[0].right) {
        this.queen[0].right = node;
        this.queen.shift();
      }
    } else {
      this.root = node;
    }

    this.queen.push(node);
  }

  getTreeResult(node) {
    if (!node || (!node.left && !node.right)) {
      return;
    }
    this.getTreeResult(node.left);
    this.getTreeResult(node.right);
    this.result.push(node.value);
  }
}
function* readline() {
  yield "1 2 3 4 5 6 7"; // 2 3 1
}
getResult();
function getResult() {
  let list = readline().next().value.split(" ");
  if (list.length === 1) {
    console.log(list[0]);
  } else {
    const tree = new Tree();
    list.forEach((item) => {
      tree.push(item);
    });
    console.log(tree);
    tree.getTreeResult(tree.root);
    console.log(tree.result.join(" "));
  }
}
