/**
 * 
 https://www.online1987.com/%e5%af%bb%e6%89%be%e6%9c%80%e5%a4%a7%e4%bb%b7%e5%80%bc%e7%9a%84%e7%9f%bf%e5%a0%86/

 【寻找最大价值的矿堆】

给你一个由 ‘0’（空地）、’1’（银矿）、’2’（金矿）组成的的地图，
矿堆只能由上下左右相邻的金矿或银矿连接形成。超出地图范围可以认为是空地。
假设银矿价值1 ，金矿价值2，请你找出地图中最大价值的矿堆并输出该矿堆的价值。

输入描述

地图元素信息如：
22220
00000
00000
11111

地图范围最大 300*300
0<= 地图元素 <=2

输出描述

矿堆的最大价值

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

22220
00000
00000
01111
输出

8
样例说明

返回公共后缀：c
 */

let directions = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];
function dfs(max_value, x, y, matrix) {
  if (matrix[x][y] == 0) {
    return max_value;
  }

  max_value += matrix[x][y];
  matrix[x][y] = 0;
  //四个方向
  for (let i = 0; i < 4; i++) {
    let new_x = x + directions[i][0];
    let new_y = y + directions[i][1];

    if (
      new_x >= 0 &&
      new_x < matrix.length &&
      new_y >= 0 &&
      new_y < matrix[0].length &&
      matrix[new_x][new_y] > 0
    ) {
      max_value = dfs(max_value, new_x, new_y, matrix);
    }
  }
  return max_value;
}

function main(matrix) {
  let max_value = 0;
  for (let i = 0; i < matrix.length; i++) {
    for (let j = 0; j < matrix[0].length; j++) {
      max_value = Math.max(max_value, dfs(0, i, j, matrix));
    }
  }
  console.log(max_value);
  return;
}

main([
  [2, 2, 2, 2, 0],
  [0, 0, 0, 2, 0],
  [0, 0, 0, 1, 0],
  [0, 1, 1, 1, 1],
]);
