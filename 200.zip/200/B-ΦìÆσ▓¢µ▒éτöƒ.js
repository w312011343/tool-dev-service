/**
 * 
 https://www.online1987.com/%e8%8d%92%e5%b2%9b%e6%b1%82%e7%94%9f/
 一个荒岛上有若干人，岛上只有一条路通往岛屿两端的港口，大家需要逃往两端的港口才可逃生。

假定每个人移动的速度一样，且只可选择向左或向右逃生。

若两个人相遇，则进行决斗，战斗力强的能够活下来，

并损失掉与对方相同的战斗力；若战斗力相同，则两人同归于尽。

输入描述

给定一行非 0 整数数组，元素个数不超过30000；
正负表示逃生方向（正表示向右逃生，负表示向左逃生），
绝对值表示战斗力，越左边的数字表示里左边港口越近，逃生方向相同的人永远不会发生决斗。

输出描述

能够逃生的人总数，没有人逃生输出0，输入异常时输出-1。

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5 10 8 -8 -5
输出

2
说明

第3个人和第4个人同归于尽，第2个人杀死第5个人并剩余5战斗力，第1个人没有遇到敌人。
 */

// const rl = require("readline").createInterface({ input: process.stdin });
// var iter = rl[Symbol.asyncIterator]();
// const readline = async () => (await iter.next()).value;

// void (async function () {
//   const nums = (await readline()).split(" ").map(Number);

//   // 负数逃生的总人数
//   let negative = 0;
//   // 正数缓冲栈，注意该栈只缓存正数
//   const positive = [];

//   // 正序遍历nums，遍历出来的num，相当于从左边逃生
//   for (let num of nums) {
//     // 输入异常时输出-1
//     if (num == 0) return console.log(-1);

//     if (num > 0) {
//       // 如果左边逃出来的是正数，则缓冲到栈中
//       positive.push(num);
//     } else {
//       // 如果左边逃出来的是负数
//       while (true) {
//         if (positive.length == 0) {
//           // 如果栈为空，即没有正数，此时左边逃出来的负数直接逃生成功
//           negative++;
//           break;
//         }

//         // 如果栈不为空，则栈中有缓冲的正数，此时负数需要和栈顶正数进行pk
//         const pk = num + positive.pop();

//         if (pk > 0) {
//           // 如果pk结果大于0，则负数逃生失败，栈顶的正数减少战斗力
//           positive.push(pk);
//           break;
//         } else if (pk < 0) {
//           // 如果pk结果小于0，则负数pk成功，此时需要继续和新栈顶正数pk，即进入下一轮
//           num = pk;
//         } else {
//           // 如果pk结果为0，则同归于尽
//           break;
//         }
//       }
//     }
//   }

//   // 最终逃生成功的人数：negative即负数逃生成功个数，positive.size()即正数逃生成功个数
//   console.log(negative + positive.length);
// })();
function* readline() {
  yield "5 10 8 -8 -5"; // 2
}
getResult();
function getResult() {
  let list = readline().next().value.split(" ").map(Number);
  let num = 0; // 向左走成功的人数
  let temp = []; // 向右走的缓存数组
  for (const item of list) {
    if (item === 0) {
      connsole.log(-1);
      return;
    }
    if (item > 0) {
      temp.push(item);
      continue;
    }
    while (true) {
      if (temp.length === 0) {
        // 没有正向缓存
        num++;
        break;
      }
      let val = item + temp.pop(); // 跟栈顶进行pk
      if (val > 0) {
        temp.push(val);
        break;
      } else if (val < 0) {
        item = val;
      } else {
        break;
      }
    }
  }

  console.log(num + temp.length);
}
