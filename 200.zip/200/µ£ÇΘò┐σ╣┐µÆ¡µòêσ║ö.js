/**
 https://www.online1987.com/%e6%9c%80%e9%95%bf%e5%b9%bf%e6%92%ad%e6%95%88%e5%ba%94/

 
 题目描述

某通信网络中有N个网络结点，用1到N进行标识。
网络中的结点互联互通，且结点之间的消息传递有时延，相连结点的时延均为一个时间单位。
现给定网络结点的连接关系link[i]={u，v}，其中u和v表示网络结点。
当指定一个结点向其他结点进行广播，所有被广播结点收到消息后都会在原路径上回复一条响应消息，请计算发送结点至少需要等待几个时间单位才能收到所有被广播结点的响应消息。
注：

N的取值范围为[1，100];
连接关系link的长度不超过3000，且1 <= u,v <= N;
网络中任意结点间均是可达的;
输入描述：

输入的第一行为两个正整数，分别表示网络结点的个数N，以及时延列表的长度T；
接下来的T行输入，表示结点间的连接关系列表；
最后一行的输入为一个正整数，表示指定的广播结点序号；
输出描述：

输出一个整数，表示发送结点接收到所有响应消息至少需要等待的时长。

5 7

2 1

1 4

2 4

2 3

3 4

3 5

4 5

2

输出

4

说明

2到5的最小时延是2个时间单位，而2到其他结点的最小时延是1个时间单位，所以2收到所有结点的最大响应时间为2*2=4。
 */


import java.util.*;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int n = sc.nextInt();

        int[][] ints = new int[m][m];
        for (int i = 0; i < m; i++) {
            ints[i][i] = 1;     
        }

        for (int i = 0; i < n; i++) {
            int r = sc.nextInt() - 1;    
            int c = sc.nextInt() - 1;
            ints[r][c] = 1;     
            ints[c][r] = 1;
        }

        int fs = sc.nextInt();
        int count = 0;  
        HashSet<Integer> hashSet = new HashSet<>(); 
        List<Integer> temp = new ArrayList<>();    
        temp.add(fs - 1); 
        hashSet.add(fs - 1);
        while (hashSet.size() < m) {

            List<Integer> list = new ArrayList<>(temp); 
            temp.clear();
            for (int j = 0; j < list.size(); j++) {
                int index = list.get(j);    
                for (int i = 0; i < m; i++) {
                    if (!hashSet.contains(i) && index != j && ints[index][i] == 1) {  
                        hashSet.add(i); 
                        temp.add(i);
                    }
                }
                if (hashSet.size() == m) { 
                    break;
                }
            }
            count++;
        }
        System.out.println(count * 2);
    }
}