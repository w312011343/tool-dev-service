/**
 * 
https://www.online1987.com/%e5%8f%91%e5%b9%bf%e6%92%ad/


题目描述

某地有N个广播站，站点之间有些有连接，有些没有。有连接的站点在接受到广播后会互相发送。
给定一个N*N的二维数组matrix,数组的元素都是字符’0’或者’1’。matrix[i][j]=‘1’,则代表i和j站点之间有连接，matrix[i][j] = ‘0’代表没连接，
现在要发一条广播，问初始最少给几个广播站发送，才能保证所有的广播站都收到消息。
输入描述：

从stdin输入，共一行数据，表示二维数组的各行，用逗号分隔行。保证每行字符串所含的字符数一样的。
比如：110,110,001。
输出描述：

返回初始最少需要发送广播站个数。
示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

110,110,001

输出

2

说明

站点1和站点2直接有连接，站点3和其他的都没连接，所以开始至少需要给两个站点发送广播。

另外一种输入形式

示例1

输入

1 0 0
0 1 0
0 0 1

输出

3

说明

3台服务器互不连接，所以需要分别广播这3台服务器。

示例2

输入

1 1
1 1

输出

1

说明

2台服务器相互连接，所以只需要广播其中一台服务器
 */

let s = readLine()
  .split(" ")
  .map((i) => {
    parseInt(i);
  });
//let s = "1 1 0 1".split(" ").map(i=>parseInt(i));

let n = s.length; //确定是n阶数组
let ints = new Array();

ints[0] = [];
for (let i = 0; i < n; i++) {
  ints[0][i] = s[i]; //第一行
}

//let test = ["1 1 0 1","1 1 1 0","0 1 1 0","1 0 0 1"];

let m = 1;
while (n > m) {
  let input = readLine()
    .split(" ")
    .map((i) => parseInt(i));
  //let input = test[m].split(" ").map(i=>parseInt(i));
  ints[m] = [];
  for (let i = 0; i < n; i++) {
    ints[m][i] = input[i]; //第i行
  }
  m++;
}

/**
 * map
 *   key:第一个节点
 *   value:可以联通的节点
 */
var map = {};
let mapKey = 0;
for (let i = 0; i < ints.length; i++) {
  let isContain = false;
  for (let key in map) {
    if (map[key].indexOf(i) != -1) {
      isContain = true;
      mapKey = key;
    }
  }
  if (!isContain) {
    map[i] = "";
    mapKey = i;
  }
  for (let j = i; j < ints.length; j++) {
    if (i != j && ints[i][j] == 1) {
      map[mapKey] += j;
    }
  }
}

console.log(Object.keys(map).length);
