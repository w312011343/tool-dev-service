/**
 * 
 https://www.online1987.com/%e8%80%83%e5%8f%a4%e9%97%ae%e9%a2%98/

 
 考古问题，假设以前的石碑被打碎成了很多块，每块上面都有一个或若干个字符，请你写个程序来把之前石碑上文字可能的组合全部写出来，按升序进行排列。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3

a b c

输出

abc

acb

bac

bca

cab

cba

示例2   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3

a b a

输出

aab

aba

baa
 */


while 1:
    try:
        chars = input().split()

        dp = []

        def dfs(sub):
            if len(sub) == len(chars):
                t = "".join(sub)
                if t not in dp:
                    dp.append(t)
            else:
                for c in chars:
                    if c not in sub:
                        dfs(sub + [c])

        for c in chars:
            dfs([c])

        print(" ".join(dp))
    except Exception as e:
        break


// let n = Number(readline());
// let strs = readline().split(" ");
let n = Number("3");
let strs = "a b ab".split(" ");
 
var list = [];
 
fullArray(strs, 0 , n-1);
list.sort();
 
for(let i=0; i<list.length; i++){
    console.log(list[i]);
}
 
function sawp( strings, a, b){
 
    let temp = strings[a];
    strings[a] = strings[b];
    strings[b] = temp;
 
}
 
function fullArray( strings, start, end){
 
    if(start == end){
        let s = "";
        for (let a of strings) {
            s += a;
        }
        if(!list.includes(s)){
            list.push(s)
        };
    }else {
        for(let i=start; i<=end; i++){
            sawp(strings, start, i);
            fullArray(strings, start+1, end);
            sawp(strings, start, i);
        }
    }
}