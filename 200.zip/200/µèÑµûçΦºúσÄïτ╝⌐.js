/**
 * 
 https://www.online1987.com/%e6%8a%a5%e6%96%87%e8%a7%a3%e5%8e%8b%e7%bc%a9/

 
 题目描述

为了提升数据传输的效率，会对传输的报文进行压缩处理。
输入一个压缩后的报文，请返回它解压后的原始报文。
压缩规则：n[str]，表示方括号内部的 str 正好重复 n 次。
注意 n 为正整数（0 < n <= 100），str只包含小写英文字母，不考虑异常情况。
输入描述:

输入压缩后的报文：

1）不考虑无效的输入，报文没有额外的空格，方括号总是符合格式要求的；

2）原始报文不包含数字，所有的数字只表示重复的次数 n ，例如不会出现像 5b 或 3[8] 的输入；

输出描述:

解压后的原始报文

注：

1）原始报文长度不会超过1000，不考虑异常的情况

示例 1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3[k]2[mn]

输出

kkkmnmn

说明

k 重复3次，mn 重复2次，最终得到 kkkmnmn

示例2  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3[m2[c]]

输出

mccmccmcc

说明

m2[c] 解压缩后为 mcc，重复三次为 mccmccmcc
 */

let s = readLine();
//let s = "3[m2[c]]";
let res = ""; //处理前的字母串
let numStr = ""; //处理多位数
let num = []; //数字队列
let zimu = []; //放置处理后的字母串
for (let i = 0; i < s.length; i++) {
  let c = s.charAt(i);
  if (!isNaN(Number(c))) {
    //判断是否为数字
    if (res.length != 0) {
      //数字前的字母暂不处理
      zimu.push(res);
      res = "";
    }
    numStr += c;
  } else if (c == "[") {
    num.push(Number(numStr)); //数字放入数字队列
    numStr = "";
  } else if (c == "]") {
    let n = num.pop(); //碰到“]”，就需要取出最上面的数字进行解压
    if (res.length != 0) {
      zimu.push(res);
      res = "";
    }
    let temp = zimu.pop(); //取出最上面的字母
    let sb = "";
    for (let j = 0; j < n; j++) {
      sb += temp; //对字母进行解压
    }
    if (zimu.length == 0) {
      zimu.push(sb);
    } else {
      zimu.push(zimu.pop() + sb); //后面处理过的字符会跟最上面的字符一起被处理
    }
  } else {
    res += c;
  }
}
console.log(zimu);
