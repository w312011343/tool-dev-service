/**
 * 
 https://www.online1987.com/%e5%88%86%e7%b3%96%e6%9e%9cii/

 【分糖果II】

Solo和koko是两兄弟，妈妈给了他们一大袋糖，每块糖上都有自己的重量。

现在他们想要将这些糖分成两堆。

分糖的任务当然落到了大哥Solo的身上，然而koko要求必须两个人获得的糖的总重量“相等”（根据Koko的逻辑），要不然就会哭的。

非常不幸的是，koko还非常小，并且他只会先将两个数转成二进制再进行加法，而且总会忘记进位。

如当12（1100）加5（101）时：

1100

+ 0101

————

1001

于是koko得到的计算结果是9（1001）。

此外还有一些例子：

5 + 4 = 1

7 + 9 = 14

50 + 10 = 56

现在Solo非常贪婪，他想要尽可能使自己得到的糖的总重量最大，且不让koko哭。

输入

输入的第一行是一个整数N(2 ≤ N ≤ 15)，表示有袋中多少块糖。

第二行包含N个用空格分开的整数Weighti (1 ≤ Weighti ≤ 10^6)，表示第i块糖的重量。

输出

如果能让koko不哭，输出Solo所能获得的糖的总重量，否则输出“NO”。

示例 1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3

3 5 6

输出

11

代码实现

 隐藏内容
样例 1解释

样例 1中，三块糖重量为3、5、6，因为5(101)+6(110)=3(11)，所以Solo拿走了重为5和6的糖，koko则得到了重为3的糖。

示例 2 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5

1 2 3 4 5

输出

NO

样例 2解释

样例 2中五块糖，无论如何分，都无法满足koko的要求，所以NO。
 */

let n = Number(readLine());
let arr = readLine().split(" ").map(Number);
// let n = Number("3");
// let arr = "3 5 6".split(" ").map(Number);

console.log(getResult(arr));

function getResult(arr) {
  if (arr.length == 2 && arr[0] != arr[1]) return "NO";
  let min = arr[0];
  let sum = min;
  let temp = min;
  for (let i = 1; i < arr.length; i++) {
    sum += arr[i];
    min = min < arr[i] ? min : arr[i];
    temp ^= arr[i];
  }
  if (temp != 0) {
    return "NO";
  } else {
    return sum - min;
  }
}
