/**
 * 
 https://www.online1987.com/%e6%89%be%e5%88%b0%e6%af%94%e8%87%aa%e5%b7%b1%e5%bc%ba%e7%9a%84%e4%ba%ba%e6%95%b0/
 

 给定数组[[2,1],[3 2]]，每组表示师徒关系，第一个元素是第二个元素的老师，数字代表排名，现在找出比自己强的徒弟。

输入

[[2,1],[3,2]]

输出

[0,1,2]

第一行数据[2,1]表示排名第 2 的员工是排名第 1 员工的导师，后面的数据以此类推。

说明

第一个元素 0 表示成绩排名第一的导师，没有徒弟考试超过他；
第二个元素 1 表示成绩排名第二的导师，有 1 个徒弟成绩超过他
第三个元素 2 表示成绩排名第二的导师，有 2 个徒弟成绩超过他

输入

[[2,1],[3,2]]

输出

[0,1,2]
 */


import json

class Node:
    def __init__(self, val):
        self.val = val
        self.students = []

class Tree:
    nodes = {}

    def get_node(self, val):
        if val not in self.nodes:
            self.nodes[val] = Node(val)
        return self.nodes[val]

    def traversal(self, root):
        if not root.students:
            return 0
        count = 0
        for stu in root.students:
            if stu.val < root.val:
                count += 1
            count += self.traversal(stu)
        return count

staffs = eval(input())

tree = Tree()
for teacher, student in staffs:
    tea = tree.get_node(teacher)
    tea.students.append(tree.get_node(student))

ret = [0] * len(tree.nodes)
for key, val in tree.nodes.items():
    ret[key-1] = tree.traversal(val)

print(json.dumps(ret).replace(" ", ""))