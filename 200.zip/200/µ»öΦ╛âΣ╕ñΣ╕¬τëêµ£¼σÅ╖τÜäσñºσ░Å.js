/**
 * 
 https://www.online1987.com/%e6%af%94%e8%be%83%e4%b8%a4%e4%b8%aa%e7%89%88%e6%9c%ac%e5%8f%b7%e7%9a%84%e5%a4%a7%e5%b0%8f/

 
 【比较两个版本号的大小】

输入两个版本号 version1 和 version2，每个版本号由多个子版本号组成。

子版本号之间由 “.” 隔开，由大小写字母、数字组成，并且至少有一个字符。

按从左到右的顺序比较子版本号，比较规则如下：

子版本号前面的0不参与比较，比如 001 和 1 是相等的。

小写字母 > 大写字母 > 数字

空字符和0相等，比如 1 和 1.0 相等

比较结果

如果 version1 > version2 ，返回 1

如果 version1 < version2 ，返回-1

其他情况返回0

示例1 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5.2
5.1a
全选代码
复制
输出

1

示例2 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5.6.1

5.6.2a

输出

-1

示例3 输入输出示例仅供调试，后台判题数据一般不包含示例

输入

5.6.8.a

5.6.8.0a

输出

0

题目解析
版本号比较常见，由字符数字组成的，从左到右其中一级较大，这个版本号就是更大的，比如：5.6.2 大于 5.6.1；
子版本号前面的0不参比较，需要对子版本号进行处理，对子版本号中起始的0进行消除，在消除时不能全部消除晚，比如：5.0000.2 和 5.1.1，5.0000.2 消除后应该是5.0.2，不能消除成5.2或者5..2；

还有一个条件是空字符和0相等，比如 1 和 1.0 相等，由于我们需要遍历子版本号，所以需要保证两个版本号一样长，在遍历时不出现越界的情况，结尾的0不影响版本号的实际意义，
可以考虑在较短的版本号后补0；

版本号的比较时，小写字母 > 大写字母 > 数字，字符a-z的ASSIC码 97~122，字符A-Z的ASSIC码 65~90，字符0-9的ASSIC码 48~57，刚好满足比较的要求可以直接比较；
在Python中我们也可以通过 ord 获取字符的ASSIC码。
 */


def _filter(version):
    # 过滤0
    v_list = version.split(".")
    v_temp = []
    for v in v_list:
        while len(v) > 1 and v[0] == "0":
            v = v[1:]
        v_temp.append(v)
    return v_temp


def _fill(version, max_len):
    # 长度填补
    if len(version) < max_len:
        version += ["0"] * (max_len - len(version))
    return version


def check(version1, version2):
    for i in range(max_len):
        if version1[i] == version2[i]:
            pass
        elif version1[i] > version2[i]:
            return "1"
        else:
            return "-1"
    return "0"


version1 = _filter(input())
version2 = _filter(input())
max_len = max(len(version1), len(version2))

version1 = _fill(version1, max_len)
version2 = _fill(version2, max_len)

print(check(version1, version2))





import java.util.Scanner;

public class VersionNumber {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String v1 = in.next();
        String v2 = in.next();

        String[] arr1 = v1.split("\\.");
        String[] arr2 = v2.split("\\.");

        int len1 = arr1.length;
        int len2 = arr2.length;

        for (int i = 0; i < len1 && i < len2; i++) {
            int res = helper(arr1[i], arr2[i]);
            if (res != 0) {
                System.out.println(res);
                return;
            }
        }

        if (len1 > len2) {
            int k = len2;
            while (k < len1) {
                int res = helper(arr1[k], "");
                if (res != 0) {
                    System.out.println(res);
                    return;
                }
                k++;
            }
            System.out.println(0);
            return;
        }

        if (len2 > len1) {
            int k = len1;
            while (k < len2) {
                int res = helper("", arr2[k]);
                if (res != 0) {
                    System.out.println(res);
                    return;
                }
                k++;
            }
            System.out.println(0);
            return;
        }

        System.out.println(0);
    }

    public static int helper(String v1, String v2) {
        StringBuilder sb1 = new StringBuilder(v1);
        while (sb1.length() > 0 && sb1.charAt(0) == '0') {
            sb1.deleteCharAt(0);
        }

        StringBuilder sb2 = new StringBuilder(v2);
        while (sb2.length() > 0 && sb2.charAt(0) == '0') {
            sb2.deleteCharAt(0);
        }

        for (int i = 0; i < sb1.length() && i < sb2.length(); i++) {
            if (sb1.charAt(i) > sb2.charAt(i)) return 1;
            else if (sb1.charAt(i) < sb2.charAt(i)) return -1;
        }

        int len1 = sb1.length();
        int len2 = sb2.length();
        if (len1 > len2) {
            int k = len2;
            while (k < len1) {
                if (sb1.charAt(k) > '0') return 1;
                k++;
            }
            return 0;
        }

        if (len2 > len1) {
            int k = len1;
            while (k < len2) {
                if (sb2.charAt(k) > '0') return -1;
                k++;
            }
            return 0;
        }
        return 0;
    }
}