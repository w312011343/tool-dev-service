/**
 * 
 

https://www.online1987.com/%e5%86%85%e5%ad%98%e8%b5%84%e6%ba%90%e5%88%86%e9%85%8d/


【内存资源分配】

定义了如下内存管理规则：

（1）按块进行内存管理，有若干个pool，每个pool管理一种大小内存块；每块内存的地址是连续的，但是内存块间地址不连续

（2）只要不超过内存块大小，该内存块可以被多次申请；

（3）一次内存申请只能从一个内存块中申请，不能跨内存块申请；

（4）剩余内存大小仅统计完全未被使用的内存块的总大小；

要求给定申请内存块的需求，求解剩下的完全未使用的内存块大小总和最大是多少？

注意：只要有一次申请不到内存，返回-1；

输入描述：

第一行输入N，代表不同规格内存的个数。
之后N行分别输入该规格内存的个数、内存的规格，使用空格分隔。
第N+2行输入M，代表需要申请的内存数目，单位为KByte 。
之后一行输入M个内存的大小，使用空格分隔。
其中N小于50，总的内存块个数小于50，M小于15。
如：三种内存块，分别是：2块大小4KByte的内存，3块大小8KByte的内存，4块大小16KByte的内存，输入格式：

3

2 4

3 8

4 16

一次申请7KByte，9KByte，11KByte，4KByte这4块内存，输入格式：

4

7 9 11 4

输出描述：

输出的剩余内存块大小：64KByte，输出格式：

64

备注：

如果没有优化方法，可能申请情况如下：
7KByte占用1个8KByte内存块，9KByte占用1个16KByte内存块，11KByte占用1个16KByte内存块，4KByte占用1个4KByte内存块
这样，完全未使用的内存块总大小是 4KByte + 2*8KByte + 2*16KByte = 52KByte
—————————————————————————————————————————————

如果优化方法，申请如下：
7KByte占用1个16KByte内存块，9KByte复用之前16KByte内存块剩下的内存，11KByte占用1个16KByte内存块，4KByte占用之前16KByte剩下的内存
这样，完全未使用的内存块总大小是 2*4KByte + 3*8KByte + 2*16KByte = 64KByte
示例1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3

2 4

3 8

4 16

4

7 9 11 4

输出

64
 */

#include<iostream>

using namespace std;
int n, m;
int num[55], need[20], sum[40000];
int f[55][40000];
int rec[55][40000];
int top{}, stop{};

int Search(int x, int y)
{
    if (x == top + 1) {
        if (y != stop) return -0x7fffffff / 3;
        return 0;
    }
    if (rec[x][y]) return f[x][y];
    int &ans = f[x][y];
    rec[x][y] = 1;
    ans = Search(x + 1, y) + num[x];
    int s = stop - y;

    for (int i = s; i; i = (i - 1) & s) {
        if (sum[i] <= num[x]) {
            ans = max(ans, Search(x + 1, y | i));
        }
    }
    return ans;
}

int main()
{
    cin >> n;
    for (int i = 0; i < n; i++) {
        int a, b;
        cin >> a >> b;
        for (int j = 0; j < a; j++)
            num[++top] = b;
    }
    cin >> m;
    for (int i = 1; i <= m; i++)
        cin >> need[i];

    stop = (1 << (m)) - 1;
    for (int i = 1; i <= stop; i++) {
        for (int j = m; j >= 1; j--)
            if (i & (1 << (j - 1))) {
                sum[i] = sum[i - (1 << (j - 1))] + need[j];
                break;
            }
    }
    int ans = Search(1, 0);
    if (ans < 0)
        printf("-1\n");
    else printf("%d\n", ans);
    return 0;
}