/**
 * 
 https://www.online1987.com/%e5%9b%be%e5%83%8f%e7%89%a9%e4%bd%93%e7%9a%84%e8%be%b9%e7%95%8c/
 

 【图像物体的边界】

给定一个二维数组M行N列，二维数组里的数字代表图片的像素，为了简化问题，仅包含像素1和5两种像素，每种像素代表一个物体，2个物体相邻的格子为边界，求像素1代表的物体的边界个数。

像素1代表的物体的边界指与像素5相邻的像素1的格子，边界相邻的属于同一个边界，相邻需要考虑8个方向（上，下，左，右，左上，左下，右上，右下）。

其他约束

地图规格约束为：

0<M<100
0<N<100

1）如下图，与像素5的格子相邻的像素1的格子（0,0）、（0,1）、（0,2）、（1,0）、（1,2）、（2,0）、（2,1）、（2,2）、（4,4）、（4,5）、（5,4）为边界，另（0,0）、（0,1）、（0,2）、（1,0）、（1,2）、（2,0）、（2,1）、（2,2）相邻，为1个边界，（4,4）、（4,5）、（5,4）相邻，为1个边界，所以下图边界个数为2。

 

2）如下图，与像素5的格子相邻的像素1的格子（0,0）、（0,1）、（0,2）、（1,0）、（1,2）、（2,0）、（2,1）、（2,2）、（3,3）、（3,4）、（3,5）、（4,3）、（4,5）、（5,3）、（5,4）、（5,5）为边界，另这些边界相邻，所以下图边界个数为1。

 

注：（2,2）、（3,3）相邻。

输入描述

第一行，行数M，列数N

第二行开始，是M行N列的像素的二维数组，仅包含像素1和5

输出描述

像素1代表的物体的边界个数。

如果没有边界输出0（比如只存在像素1，或者只存在像素5）。

示例1   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

6 6
1 1 1 1 1 1
1 5 1 1 1 1
1 1 1 1 1 1
1 1 1 1 1 1
1 1 1 1 1 1
1 1 1 1 1 5

输出

2

说明

参考题目描述部分

示例2   输入输出示例仅供调试，后台判题数据一般不包含示例

输入

6 6
1 1 1 1 1 1
1 5 1 1 1 1
1 1 1 1 1 1
1 1 1 1 1 1
1 1 1 1 5 1
1 1 1 1 1 1

输出

1

说明

参考题目描述部分
 */
var hang = Number(readLine());
var lie = Number(readLine());
// var hang = Number("6");
// var lie = Number("6");

var ints = [];
// var ints = [[1,1,1,1,1,1],
//             [1,5,1,1,1,1],
//             [1,1,1,1,1,1],
//             [1,1,1,1,1,1],
//             [1,1,1,1,1,1],
//             [1,1,1,1,1,5]];

for (let i = 0; i < hang; i++) {
  ints[i] = [];
  let str = readLine().split(" ");
  for (let j = 0; j < lie; j++) {
    ints[i][j] = Number(str[j]);
  }
}

/**
 * 将5周围的1转变为2作为边界
 * 遍历数组找到边界2，将其变为0，再通过递归将其周围的2全部变为0
 * 如果边界相邻则所有的2都会变为0
 */
for (let i = 0; i < hang; i++) {
  for (let j = 0; j < lie; j++) {
    if (ints[i][j] == 5) {
      if (i > 0) {
        //表示上面有值
        if (ints[i - 1][j] == 1) {
          //正上方
          ints[i - 1][j] = 2; //边界用0表示
        }
        if (j > 0) {
          //表示左边有值
          if (ints[i - 1][j - 1] == 1) {
            //左上方
            ints[i - 1][j - 1] = 2;
          }
        }
        if (j < lie - 1) {
          //右边有值
          if (ints[i - 1][j + 1] == 1) {
            //右上方
            ints[i - 1][j + 1] = 2;
          }
        }
      }
      if (j > 0) {
        //表示左边有值
        if (ints[i][j - 1] == 1) {
          //左边
          ints[i][j - 1] = 2;
        }
      }
      if (i < hang - 1) {
        //表示下面有值
        if (ints[i + 1][j] == 1) {
          //正下方
          ints[i + 1][j] = 2;
        }
        if (j > 0) {
          //表示左边有值
          if (ints[i + 1][j - 1] == 1) {
            //左下方
            ints[i + 1][j - 1] = 2;
          }
        }
        if (j < lie - 1) {
          //右边有值
          if (ints[i + 1][j + 1] == 1) {
            //右下方
            ints[i + 1][j + 1] = 2;
          }
        }
      }
      if (j < lie - 1) {
        //右边有值
        if (ints[i][j + 1] == 1) {
          //右边
          ints[i][j + 1] = 2;
        }
      }
    }
  }
}

let count = 0; //边界个数
for (let i = 0; i < hang; i++) {
  for (let j = 0; j < lie; j++) {
    if (ints[i][j] == 2) {
      count++;
      ints[i][j] = 0;
      qingchuBianjie(i, j);
    }
  }
}
console.log(count);

function qingchuBianjie(i, j) {
  if (i > 0) {
    //表示上面有值
    if (ints[i - 1][j] == 2) {
      //正上方
      ints[i - 1][j] = 0;
      qingchuBianjie(i - 1, j);
    }
    if (j > 0) {
      //表示左边有值
      if (ints[i - 1][j - 1] == 2) {
        //左上方
        ints[i - 1][j - 1] = 0;
        qingchuBianjie(i - 1, j - 1);
      }
    }
    if (j < lie - 1) {
      //右边有值
      if (ints[i - 1][j + 1] == 2) {
        //右上方
        ints[i - 1][j + 1] = 0;
        qingchuBianjie(i - 1, j + 1);
      }
    }
  }
  if (j > 0) {
    //表示左边有值
    if (ints[i][j - 1] == 2) {
      //左边
      ints[i][j - 1] = 0;
      qingchuBianjie(i, j - 1);
    }
  }
  if (i < hang - 1) {
    //表示下面有值
    if (ints[i + 1][j] == 2) {
      //正下方
      ints[i + 1][j] = 0;
      qingchuBianjie(i + 1, j);
    }
    if (j > 0) {
      //表示左边有值
      if (ints[i + 1][j - 1] == 2) {
        //左下方
        ints[i + 1][j - 1] = 0;
        qingchuBianjie(i + 1, j - 1);
      }
    }
    if (j < lie - 1) {
      //右边有值
      if (ints[i + 1][j + 1] == 2) {
        //右下方
        ints[i + 1][j + 1] = 0;
        qingchuBianjie(i + 1, j + 1);
      }
    }
  }
  if (j < lie - 1) {
    //右边有值
    if (ints[i][j + 1] == 2) {
      //右边
      ints[i][j + 1] = 0;
      qingchuBianjie(i, j + 1);
    }
  }
}



def edges(grid, row, col):
    def dfs(grid, i, j):
        grid[i][j] = 6
        for x in range(i - 3, i + 4):
            for y in range(j - 3, j + 4):
                if x < 0 or y < 0 or x >= row or y >= col:
                    continue

                if grid[x][y] == 5:
                    dfs(grid, x, y)

    res = 0
    for i in range(row):
        for j in range(col):
            if grid[i][j] == 5:
                res += 1
                dfs(grid, i, j)

    return res


if __name__ == '__main__':
    row, col = 20, 20
     grid = [[1, 1, 1, 1, 1, 1,],
             [1, 5, 1, 1, 1, 1,],
             [1, 1, 1, 1, 1, 1,],
             [1, 1, 1, 1, 1, 1,],
             [1, 1, 1, 1, 1, 1,],
             [1, 1, 1, 1, 1, 5,] ]


    res = edges(grid, row, col)
    print(res)



pythhon2


m, n = input().split()
map = [input().split() for _ in range(int(m))]

spot_aggs = []

for x in range(int(m)):
    for y in range(int(n)):
        if map[x][y] == '5':
            if not spot_aggs:
                spot_aggs.append({(x, y)})
                continue
            # 不相邻矩阵集合
            tmp = []
            for agg in spot_aggs:
                # 和相邻矩阵中任意一个5相邻，加入这个集合
                for spot in agg:
                    if is_adjacent(spot, (x, y)):
                        tmp.append(agg)
                        break
            if len(tmp) == 1:
                tmp[0].add((x, y))
            elif len(tmp) > 1:
                # 合并相邻集合
                new_agg = {(x, y)}
                for i in tmp:
                    new_agg.update(i)
                    spot_aggs.remove(i)
                spot_aggs.append(new_agg)
            else:
                # 和每个矩阵集合都不相邻，创建一个新集合
                spot_aggs.append({(x, y)})

print(len(spot_aggs))
