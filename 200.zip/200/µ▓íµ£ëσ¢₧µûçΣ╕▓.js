/**
 https://www.online1987.com/%e6%b2%a1%e6%9c%89%e5%9b%9e%e6%96%87%e4%b8%b2/

 【没有回文串】

回文串的定义：正读和反读都一样的字符串现在已经存在一个不包含回文串的字符串，字符串的字符都是在英语字母的前N个,且字符串不包含任何长度大于等于2的回文串；

请找出下一个字典序的不包含回文串的、字符都是在英语字母的前N个、且长度相同的字符串。

如果不存在，请输出NO。

输入描述

输入包括两行。

第一行有一个整数:N（1<=N<=26），表示字符串的每个字符范围都是前N的英语字母。

第二行输入一个字符串（输入长度<=10000），输入保证这个字符串是合法的并且没有包含回文串。

输出描述

输出下一个字典序的不包含回文串的、字符都是在英语字母的前N个、且长度相同的字符串；

如果不存在,请输出”NO“。

示例1  输入输出示例仅供调试，后台判题数据一般不包含示例

输入

3

cba

输出

NO
 */
import java.util.Scanner;

public class Main {
    private static int nn;
    private static int pp;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        nn = sc.nextInt();
        pp = sc.nextInt();
        sc.nextLine();
        String strInput = sc.nextLine();
        char[] str = strInput.toCharArray();
        if (checkResult(str, nn - 1)) {
            System.out.println(String.valueOf(str));
        } else {
            System.out.println("NO");
        }
    }

    private static boolean checkResult(char[] input, int pos) {
        if (pos < 0) {
            return false;
        }
        if (pos == nn) {
            return true;
        }
        char dotPos = input[pos];
        char before = pos > 0 ? input[pos - 1] : '1';
        char beforeBefore = pos > 1 ? input[pos - 2] : '2';
        for (char ch = (char) (dotPos + 1); ch < (char) ('a' + pp); ch = (char) (ch + 1)) {
            input[pos] = ch;
            if (isHuiWen(beforeBefore, before, ch)) {
                continue;
            }
            if (checkResult(input, pos + 1)) {
                return true;
            }
        }
        input[pos] = 'a' - 1; 
        return checkResult(input, pos - 1);
    }

    private static boolean isHuiWen(char a, char b, char c) {
        return a == c || b == c || a == b;
    }
}